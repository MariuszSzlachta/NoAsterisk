# Anti-Patterns — Learned from FE Reviews

These exact mistakes were made in this project. NEVER repeat them.

---

## AP-FE-1: Port/Facade around Zustand store

```typescript
// ❌ Unnecessary abstraction — store IS the abstraction
export interface ImportStatePort {
  readonly rows: ReadonlyArray<TransactionViewModel>;
  addRows(rows: TransactionViewModel[]): void;
}
export const useImportState = (): ImportStatePort => useImportStoreInternal();

// ✅ Direct Zustand hook — no port wrapping
export const useImportStore = create<ImportStoreState>((set) => ({
  rows: [],
  addRows: (rows) => set((state) => ({ rows: [...state.rows, ...rows] })),
}));
```

**Why:** Zustand hook IS already the abstraction. Adding a port interface adds zero value — it's not like you'll swap Zustand for something else without rewriting the hook anyway. Extra indirection = extra confusion = extra bugs.

---

## AP-FE-2: DDD entities with behavior on frontend

```typescript
// ❌ Backend pattern forced onto frontend
export class Transaction {
  private constructor(readonly id: string, readonly amount: Money) {}
  static create(props: CreateProps): Transaction { /* validates */ }
  static fromViewModel(vm: TransactionViewModel): Transaction { /* reconstitutes */ }
  anonymize(result: AnonymizationResult): Transaction { /* returns new instance */ }
}

// ✅ Plain interfaces + pure functions
export interface TransactionViewModel {
  readonly id: string;
  readonly amount: number;
  readonly currency: string;
}

export const validateTransaction = (values: FormValues): FieldErrors => { ... };
export const mapDtoToTransaction = (dto: TransactionDto): TransactionViewModel => { ... };
```

**Why:** Frontend doesn't persist entities. No identity lifecycle. No reconstitution from DB. Classes with `.create()` add ceremony without value. Pure functions are simpler, testable, and composable.

---

## AP-FE-3: Inline callbacks in components

```typescript
// ❌ Logic leaks into JSX
<Button onClick={() => store.deleteRow(id)}>Delete</Button>
<Input onChange={(e) => setFilter(e.target.value)} />

// ✅ Handler from hook
const { handleDelete } = useRowActions(id);
<Button onClick={handleDelete}>Delete</Button>
```

**Why:** Inline callbacks make components harder to test, harder to trace, and create new function references on every render. Hooks encapsulate intent.

---

## AP-FE-4: Raw DTO in component props

```typescript
// ❌ Component couples to API shape
interface Props { data: ApiTransactionResponse; }

// ✅ Component receives ViewModel
interface Props { vm: TransactionViewModel; }
```

**Why:** API changes cascade into component changes. ViewModel is the contract between data and UI — stable regardless of backend restructuring.

---

## AP-FE-5: Business logic in component body

```typescript
// ❌ Filtering, sorting, calculation in component
export const TransactionList = ({ items }: Props): React.JSX.Element => {
  const filtered = items.filter(i => i.amount > 0 && i.category !== 'excluded');
  const sorted = filtered.sort((a, b) => b.date.localeCompare(a.date));
  const total = sorted.reduce((sum, i) => sum + i.amount, 0);
  return <div>...</div>;
};

// ✅ Logic in hook, component just renders
export const TransactionList = (): React.JSX.Element => {
  const { items, total } = useTransactionList();
  return <div>...</div>;
};
```

**Why:** Components become untestable, unreadable, and unreusable when filled with logic. Hooks are the unit of business logic on frontend.

---

## AP-FE-6: Hardcoded colors instead of design tokens

```typescript
// ❌ Hardcoded — breaks theme switching
className="bg-[#101319] text-[#e8eaee] border-[#21262f]"

// ✅ Design tokens — auto-switch with theme
className="bg-surface text-foreground border-border"
```

**Why:** Hardcoded hex = broken dark/light mode. Design tokens = one source of truth for theming.

---

## AP-FE-7: Direct library imports in features

```typescript
// ❌ Feature directly imports charting library
import { ResponsiveLine } from '@nivo/line';

// ✅ Feature uses shared adapter
import { LineChart } from '#shared/adapters/charts';
```

**Why:** Library swap = touching every feature. Adapter = swap in one place.

---

## AP-FE-8: God component (200+ lines, embedded sub-layouts)

```tsx
// ❌ Everything in one file
export const DashboardPage = (): React.JSX.Element => {
  // 20 lines of hooks
  // 150 lines of JSX with nested divs, conditionals, maps
};

// ✅ Composed from named sub-components
export const DashboardPage = (): React.JSX.Element => (
  <PageLayout>
    <KpiRow />
    <SpendingChart />
    <BudgetProgress />
    <RecentTransactions />
  </PageLayout>
);
```

**Why:** Unreadable, untestable, impossible to modify without breaking siblings. Each visual "unit" gets its own component.

---

## AP-FE-9: useEffect for derived state

```typescript
// ❌ Effect + state for something that's just a computation
const [total, setTotal] = useState(0);
useEffect(() => { setTotal(rows.reduce((s, r) => s + r.amount, 0)); }, [rows]);

// ✅ Derive in render — it's just math
const total = rows.reduce((s, r) => s + r.amount, 0);
```

**Why:** Unnecessary re-render cycle. Derived state = compute it. No effect, no extra state variable.

---

## AP-FE-10: Function keyword instead of arrow

```typescript
// ❌ Inconsistent — project uses arrows everywhere
export function AnalyticsPage(): React.JSX.Element { ... }

// ✅ Arrow function, consistent with project convention
export const AnalyticsPage = (): React.JSX.Element => { ... };
```

**Why:** Convention consistency. The entire codebase uses arrow functions. Mixing styles confuses readers and linters.

# Frontend Code Quality — React/TypeScript Conventions

**This is NOT DDD on the frontend.** No domain entities with behavior, no value objects with invariants, no rich models. Frontend `model/` layer holds plain types, interfaces, and pure transformer functions. That's it.

---

## File Organization — Directory Per File

**Every `.ts` / `.tsx` file lives in its own directory with an `index.ts` barrel.**

```
// ✅ Always
AnalyticsToolbar/
  AnalyticsToolbar.tsx
  index.ts               ← export { AnalyticsToolbar } from './AnalyticsToolbar';

useKpiWidget/
  useKpiWidget.ts
  useKpiWidget.spec.ts
  index.ts

// ❌ Never — loose files
ui/
  AnalyticsToolbar.tsx
  AnalyticsChart.tsx
  useKpiWidget.ts
```

Exceptions (files that do NOT need a directory):
- `index.ts` (barrel re-exports at feature/layer root)
- `types.ts` in `model/`
- Single-file configs (`constants.ts`, `nivo-defaults.ts`)

## 1 TSX File = 1 Component, Nothing Else

A `.tsx` file contains EXACTLY one React component. Zero helper functions, zero utils, zero sub-components.

```typescript
// ✅ AnalyticsToolbar.tsx — only the component
export const AnalyticsToolbar = (props: AnalyticsToolbarProps): React.JSX.Element => {
  const { filters, setFilters } = useAnalyticsFilters();
  return ( /* JSX */ );
};

// ❌ Helper function living in component file
const formatLabel = (period: Period): string => { ... }; // ← move to model/ or shared/lib/

export const AnalyticsToolbar = () => { ... };
```

Where helpers go:
- Feature-specific logic → `model/` (pure functions)
- Generic formatting → `shared/lib/`
- Component-specific derived data → dedicated hook in `ui/hooks/`

## Arrow Functions — Always

```typescript
// ✅ Arrow function, named export
export const HomePage = (): React.JSX.Element => {
  return <div>Home</div>;
};

// ✅ Arrow for hooks
export const useImportState = (): ImportStatePort => { ... };

// ❌ function keyword
export function HomePage(): React.JSX.Element { ... }
```

Exception: none. Arrow functions everywhere — components, hooks, handlers, utils.

## Zero Inline Callbacks — All Logic in Hooks

**Any logic — event handlers, callbacks, computations — lives in a dedicated hook. Component body = hook calls + return JSX. Period.**

```typescript
// ✅ ALL handlers come from hooks
export const TransactionRow = ({ vm }: TransactionRowProps): React.JSX.Element => {
  const { handleEdit, handleDelete, handleSelect } = useTransactionRowActions(vm.id);

  return (
    <tr>
      <td>{vm.title}</td>
      <td><Button onClick={handleEdit}>Edit</Button></td>
      <td><Button onClick={handleDelete}>Delete</Button></td>
    </tr>
  );
};

// ❌ Inline callback — even "simple" ones
<Button onClick={() => setOpen(true)}>Open</Button>
<Button onClick={() => store.delete(id)}>Delete</Button>
<Input onChange={(e) => setFilter(e.target.value)} />

// ❌ Named handler defined in component body (not hook)
export const TransactionRow = ({ vm }: Props): React.JSX.Element => {
  const handleEdit = (): void => { navigate(`/edit/${vm.id}`); }; // ← this belongs in a hook
  return <Button onClick={handleEdit}>Edit</Button>;
};
```

Rules:
- Component body: `const { ... } = useMyHook();` → `return (<JSX/>);`. Nothing between.
- One hook per logical concern (e.g. `useTransactionRowActions`, `useFilterToolbar`).
- Hook returns named handlers + derived state. Component just renders.

## No Premature useCallback/useMemo

```typescript
// ✅ Just define it — no useCallback
const handleClick = (id: string): void => {
  store.selectRow(id);
};

// ❌ Premature memoization
const handleClick = useCallback((id: string) => { store.selectRow(id); }, [store]);
```

Add `useCallback`/`useMemo` ONLY when:
- Measured performance problem (React DevTools profiler)
- Passing to memoized child (`React.memo`) that re-renders excessively
- Expensive computation (>1ms measured)

## useEffect — Minimize

Prefer:
- **Derived state** (compute in render or useMemo) over useEffect + setState
- **Event handlers** (respond to action) over useEffect (respond to state change)

```typescript
// ✅ Derived — no effect needed
const totalAmount = rows.reduce((sum, r) => sum + r.amount, 0);

// ❌ Effect + state for derived data
const [total, setTotal] = useState(0);
useEffect(() => { setTotal(rows.reduce(...)); }, [rows]);
```

Valid useEffect uses:
- Sync with external system (DOM manipulation, subscription, timer)
- One-time initialization (fetch on mount with cleanup)

## react-hooks/exhaustive-deps = ERROR

No suppress, no ignore. If deps are wrong — fix the logic, not the lint rule.

```typescript
// ❌
// eslint-disable-next-line react-hooks/exhaustive-deps
useEffect(() => { ... }, []);

// ✅ If you don't want re-runs, restructure:
const stableRef = useRef(callback);
stableRef.current = callback;
useEffect(() => { stableRef.current(); }, []);
```

## Imports — Subpath Aliases (#)

```typescript
// ✅ Aliased
import { useImportState } from '#features/csv-import';
import { formatMoney } from '#shared/lib';
import { KpiCard } from '#shared/ui/KpiCard';

// ❌ Relative hell
import { formatMoney } from '../../../shared/lib/formatMoney';
```

Aliases defined in `client/package.json` `"imports"` field:
- `#app/*` → `./src/app/*`
- `#pages/*` → `./src/pages/*`
- `#features/*` → `./src/features/*`
- `#entities/*` → `./src/entities/*`
- `#shared/*` → `./src/shared/*`

## Constants — No Magic Values in Components

```typescript
// ✅ Extracted to constants file
const CHART_MARGIN = { top: 20, right: 20, bottom: 50, left: 60 } as const;
const DEFAULT_PAGE_SIZE = 20;

// ❌ Inline magic
<ResponsiveBar margin={{ top: 20, right: 20, bottom: 50, left: 60 }} />
```

## Generics — Descriptive Names

```typescript
// ✅ Descriptive
get<TResponse extends Record<string, unknown>>(path: string): Promise<TResponse>
post<TResponse extends Record<string, unknown>, TBody extends Record<string, unknown>>(...)

// ❌ Single letter
get<T>(path: string): Promise<T>
```

Convention: `TResponse`, `TBody`, `TRow`, `TData`.

## Anti-Patterns Summary

| ❌ | ✅ |
|---|---|
| `function` keyword | Arrow functions |
| Inline callback `onClick={() => ...}` | Handler from hook |
| Any logic/handler defined in component body | Dedicated hook |
| Helper function in `.tsx` file | `model/` or `shared/lib/` |
| Multiple components in one file | 1 file = 1 component |
| Loose file without directory | `Name/Name.tsx` + `index.ts` |
| useCallback/useMemo by default | Only when measured problem |
| useEffect for derived state | Compute in render/hook body |
| `// eslint-disable-next-line` | Fix the code, not the lint |
| Relative imports `../../..` | Subpath aliases `#shared/...` |
| Magic numbers in JSX | Named constants |
| DDD entities/value objects on FE | Plain interfaces + pure functions |
| Domain behavior (`.validate()`, `.create()`) | Transform in `model/transformers.ts` |

---

## Styling — Tailwind Classes Only

### Rules

- **Zero inline `style={{}}`** — use Tailwind utility classes.
- **Zero SCSS/CSS modules** — not needed with Tailwind v4.
- **Zero CSS-in-JS** (styled-components, emotion) — native CSS is faster.
- Colors MUST come from design tokens (`bg-primary`, `text-income`, `border-border`). Never hardcode hex.

### Design Tokens (source: `client/src/index.css`)

```
Surfaces:   bg-background, bg-surface, bg-surface-2, bg-surface-3
Text:       text-foreground, text-muted-foreground, text-subtle
Primary:    bg-primary, text-primary, bg-primary-soft
Financial:  text-income, bg-income-soft, text-expense, bg-expense-soft, text-warning
Borders:    border-border, border-border-strong
Categories: text-cat-groceries, text-cat-transport, text-cat-subscriptions, etc.
```

### Dark Mode

Default theme is dark (`class="dark"` on `<html>`). Light via `.light` class.
Components do NOT need `dark:` variants — tokens auto-switch via CSS variables.

```tsx
// ✅ Works in both themes automatically
<div className="bg-surface border-border text-foreground">

// ❌ Hardcoded colors — breaks in theme switch
<div className="bg-[#101319] border-[#21262f] text-[#e8eaee]">

// ❌ Manual dark variants — unnecessary with CSS var tokens
<div className="bg-white dark:bg-gray-900">
```

### Typography

```tsx
// Body text
<p className="font-sans text-sm text-muted-foreground">

// Financial amounts (tabular figures, monospace)
<span className="font-mono text-sm tabular-nums text-foreground">1 234,56 zł</span>

// Income / expense
<span className="font-mono tabular-nums text-income">+8 500,00 zł</span>
<span className="font-mono tabular-nums text-expense">−87,43 zł</span>
```

### Allowed `style={{}}` (exceptions)

Only when value is dynamic and unknown at compile time:
```tsx
// ✅ Dynamic width from JS calculation
<div style={{ width: `${percentage}%` }} className="h-2 rounded-full bg-primary" />

// ✅ AG Grid cell renderer (AG Grid API requires it)
// ❌ Everything else — use Tailwind
```

### Radius & Shadows

```tsx
<div className="rounded-sm">   // 6px
<div className="rounded-md">   // 9px (buttons, inputs)
<div className="rounded-lg">   // 12px (cards, panels)
<div className="shadow-card">  // card elevation
```

### Animations

Use Tailwind built-in transitions:
```tsx
<button className="transition-colors duration-150 hover:bg-primary-soft">
<div className="transition-all duration-200 ease-out">
```

For complex animations: add `@keyframes` in `index.css` under `@theme`, expose via `--animate-*` token.

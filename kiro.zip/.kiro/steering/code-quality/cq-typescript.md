# TypeScript Conventions

## Strict Mode — Non-Negotiable

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noUnusedLocals": true,
    "noImplicitOverride": true,
    "noFallthroughCasesInSwitch": true
  }
}
```

## Forbidden

- `any` — always. Use `unknown` with type guards.
- `!` (non-null assertion) — use type guard or null check.
- `as` (type assertion) — use type guard. Exception: `Object.keys(Enum) as Array<keyof typeof Enum>`.
- `@ts-ignore` / `@ts-expect-error` — fix the type.
- `eval()`, `Function()` — never.

## Interfaces vs Types

Use `interface` for object shapes. Use `type` for unions, intersections, mapped types.

```typescript
// ✅ Interface for objects
interface Transaction {
  id: string;
  amount: Money;
  title: AnonymizedTitle;
}

// ✅ Type for unions
type ImportResult =
  | { status: 'success'; count: number }
  | { status: 'error'; message: string };
```

## Discriminated Unions Over Optionals

Model state variants as separate interfaces — never one interface with many optional fields.

```typescript
// ✅ Discriminated union
type CategorizationResult =
  | { status: 'matched'; category: Category; rule: CategorizationRule }
  | { status: 'unmatched'; transactionId: string }
  | { status: 'ai_suggested'; category: Category; confidence: number };

// ❌ Optional soup
interface CategorizationResult {
  status: string;
  category?: Category;
  rule?: CategorizationRule;
  confidence?: number;
}
```

## Value Objects as Classes (Backend only)

> Frontend uses plain interfaces + pure functions — see `cq-react.md`.

Domain concepts get their own types — no primitive obsession.

```typescript
// ✅ Value Object
export class Money {
  constructor(
    readonly amount: number,
    readonly currency: string,
  ) {
    if (amount < 0) throw new Error('Amount cannot be negative');
  }

  add(other: Money): Money {
    if (this.currency !== other.currency) throw new Error('Currency mismatch');
    return new Money(this.amount + other.amount, this.currency);
  }
}

// ❌ Raw primitive
function transfer(amount: number, currency: string): void { ... }
```

## Explicit Return Types

Every exported function must have an explicit return type.

```typescript
// ✅
export const calculateBudgetRemaining = (budget: SubBudget): Money => { ... };

// ❌ — implicit inference
export const calculateBudgetRemaining = (budget: SubBudget) => { ... };
```

## Enums

String enums with values equal to keys. Use `Record<Enum, Value>` for exhaustive mapping.

```typescript
export enum TransactionStatus {
  Pending = 'Pending',
  Categorized = 'Categorized',
  Rejected = 'Rejected',
}

const STATUS_LABELS: Record<TransactionStatus, string> = {
  [TransactionStatus.Pending]: 'Awaiting categorization',
  [TransactionStatus.Categorized]: 'Done',
  [TransactionStatus.Rejected]: 'Rejected by user',
};
```

## Zod at Boundaries

Every external input validated with Zod before entering application layer.

```typescript
// presentation/dto/import-csv.dto.ts
import { z } from 'zod';

export const ImportCsvSchema = z.object({
  transactions: z.array(z.object({
    date: z.string().datetime(),
    amount: z.number(),
    anonymizedTitle: z.string().min(1).max(255),
  })),
  profileId: z.string().uuid(),
});

export type ImportCsvDto = z.infer<typeof ImportCsvSchema>;
```

## Naming

| Context | Convention | Example |
|---|---|---|
| Interface | Descriptive noun | `Transaction`, `SubBudget` |
| Port interface | `*Port` suffix | `CategorizationPort`, `InsightPort` |
| Adapter class | `*Adapter` suffix | `ClaudeCategoryAdapter` |
| Repository | `*Repository` suffix | `TransactionRepository` |
| Command | `*Command` | `ImportCsvCommand` |
| Query | `*Query` | `GetBudgetSummaryQuery` |
| Handler | `*Handler` | `ImportCsvHandler` |
| DTO | `*Dto` | `ImportCsvDto` |
| Value Object | Domain name (no suffix) | `Money`, `DateRange` |
| Boolean | `is*`, `has*`, `can*`, `should*` | `isAnonymized`, `canAfford` |

## `undefined` vs `null`

Prefer `undefined`. Use `null` only when PostgreSQL/API explicitly requires it.

## Type Narrowing

```typescript
// ✅ Type guard
const isCategorizationResult = (value: unknown): value is CategorizationResult =>
  typeof value === 'object' && value !== null && 'status' in value;

// ❌ Cast
const result = rawValue as CategorizationResult;
```

## Generics — Use When Type Varies

```typescript
// ✅ Generic repository port
export interface RepositoryPort<T> {
  findById(id: string): Promise<T | undefined>;
  save(entity: T): Promise<void>;
}
```

# Clean Architecture
## Frontend — Feature-Sliced Design (FSD)

**NOT hexagonal inside features.** No ports, no adapters, no "infrastructure" layer within features.
Ports/adapters exist ONLY in `shared/adapters/` for swappable external libraries (Nivo, AG Grid).

---

### Top-Level Structure (FSD)

```
src/
  app/                    ← Bootstrap, providers, routing, global layouts
    providers/            ← React context providers (auth, theme, query client)
    routing/              ← Route definitions, guards (auth, roles)
    layouts/              ← Shell layouts (AppShell, TopBar, Sidebar)

  pages/                  ← Route composites — compose features per view
    DashboardPage.tsx
    AnalyticsPage.tsx
    ImportPage.tsx
    TransactionsPage.tsx
    BudgetsPage.tsx
    AdminRulesPage.tsx

  features/               ← Self-contained business capabilities
    analytics/
    dashboard-widgets/
    csv-import/
    categorization/
    batch-edit/

  entities/               ← Shared domain objects (cross-feature)
    transaction/
    import-batch/
    user/

  shared/                 ← Zero business logic — pure infrastructure
    ui/                   ← Design system (Button, Modal, Card, KpiCard, etc.)
    lib/                  ← Utilities (date, money formatting)
    api/                  ← HTTP client, auth interceptor, query helpers
    adapters/             ← ONLY place with port/adapter pattern (external libs)
    hooks/                ← Generic hooks (useDebounce, useLocalStorage)
    i18n/                 ← Internationalization config + locales
    types/                ← Global type utilities
```

### Feature Internals — Plain FSD Layers

No hexagonal, no "infrastructure", no "application" layer. Features are flat and simple.

#### Standard feature

```
features/{name}/
  model/
    types.ts             ← Types, ViewModels, interfaces
    transformers.ts      ← DTO → ViewModel mappers (pure functions)
    transformers.spec.ts ← Tests for transformers
    *.ts                 ← Pure functions (parsers, validators)

  api/
    use*Query.ts         ← TanStack Query hooks (server state)

  ui/
    *.tsx                ← React components (rendering only)
    {ComponentName}/     ← Directory per complex component
      ComponentName.tsx
      index.ts
    hooks/               ← UI hooks (combine API data + transformers → ViewModel)
    constants/           ← UI constants, config objects

  index.ts              ← Public API — ONLY exported surface
```

#### Feature with local store (e.g. wizard, filters)

Same as above plus one Zustand store file:

```
features/{name}/
  model/
  api/
  store/
    use{Name}Store.ts    ← Zustand store (plain, no port wrapping)
  ui/
  index.ts
```

Store is just a Zustand `create()` — no port interface around it.
Hook in `ui/hooks/` or top-level can use the store directly.

### Dependency Rule

```
pages → features → entities → shared
```

Inside a feature:
```
ui/ → model/
ui/ → api/
ui/ → store/
```

- `model/` imports NOTHING from other feature layers or React.
- `ui/` consumes data via hooks that call `api/` and transform via `model/`.
- Features NEVER import from each other.
- Pages compose features (layout + wiring, zero logic).

### Port/Adapter Pattern — ONLY for External Libraries in shared/

**Explicit rule: Do NOT use port/adapter pattern inside features. No `infrastructure/`, no `application/`, no port interfaces for Zustand or internal state.**

Ports exist ONLY in `shared/adapters/` to isolate swappable third-party libraries:

```
shared/adapters/
  charts/
    ports/chart.port.ts         ← Generic: LineChartProps, BarChartProps, PieChartProps
    adapters/nivo/              ← Nivo implementation
    index.ts                    ← Re-exports as generic names (LineChart, BarChart, PieChart)

  grid/
    ports/grid.port.ts          ← Generic grid column/props interface
    adapters/ag-grid/           ← AG Grid Community implementation
    index.ts                    ← Re-exports as DataGrid
```

Features import ONLY from index:
```typescript
import { LineChart } from '#shared/adapters/charts';
import { DataGrid } from '#shared/adapters/grid';
```

Swap Nivo → Recharts = change adapters + index re-exports. Zero feature changes.

**Where ports do NOT go:**
- ❌ Around Zustand stores
- ❌ Around TanStack Query hooks
- ❌ Around feature-internal state
- ❌ Inside any feature directory

### Mappers (Transformers)

```
API Response (DTO from TanStack Query)
   ↓ [model/transformers: DTO → ViewModel]
ViewModel (plain object, UI-ready)
   ↓ [via ui/hooks/ or direct props]
React Component (rendering only)
```

Rules:
- Components NEVER receive raw API DTOs as props.
- ViewModels are plain objects (interfaces).
- Transformers are pure functions in `model/` — easily testable.

### State Management Split

| What | Where | Why |
|---|---|---|
| Server data (lists, details) | TanStack Query (`api/use*Query.ts`) | Cache, refetch, stale-while-revalidate |
| Local pipeline state (import wizard) | Zustand (`store/use*Store.ts`) | Complex state machine, in-memory |
| UI state (selections, filters) | Zustand (same or separate store) | Feature-local, transient |
| Derived display data | `ui/hooks/` | Combine query + store + transform → ViewModel |
| Form state | Form library or local `useState` | Per-component lifecycle |

### Optimistic Locking

ViewModel holds `version: number`. On PATCH we send version, backend checks:
- 200 → update local version in cache
- 409 → rollback optimistic update, show conflict UI

### index.ts — Public API Contract

Every feature MUST export through `index.ts`. This is the ONLY surface other layers can import.

```typescript
// features/analytics/index.ts
export { AnalyticsToolbar } from '#features/analytics/ui/AnalyticsToolbar';
export { AnalyticsChart } from '#features/analytics/ui/AnalyticsChart';
export { useAnalyticsFilters } from '#features/analytics/ui/hooks/useAnalyticsFilters';
export type { AnalyticsFilters, MetricType, Period } from '#features/analytics/model/types';
```

Rules:
- Export components, hooks, types that pages need.
- NEVER export store internals or internal hooks not meant for pages.

### Data Flow Example (Dashboard Widget)

```
Page mounts → TanStack Query hook fires (api/useKpiQuery)
   ↓ backend responds with DTO
UI hook (ui/hooks/useKpiWidget) calls transformer
   ↓ model/transformers: DTO → KpiViewModel
Component receives KpiViewModel via hook
   ↓ renders pure UI (KpiCard from shared/ui)
```

### Anti-Patterns (Frontend)

| ❌ Doing this | ✅ Do this instead |
|---|---|
| Creating `infrastructure/` or `application/` dirs in feature | Use flat: `model/`, `api/`, `store/`, `ui/` |
| Port interface around Zustand store | Use store directly, it's internal |
| Port interface around TanStack Query | It's already an abstraction, use directly |
| Raw DTO in component props | Map to ViewModel via `model/transformers` |
| Feature importing from another feature | Extract to `entities/` or `shared/` |
| God store (all state in one place) | Per-feature store + TanStack Query |
| Direct AG Grid import in feature | `import { DataGrid } from '#shared/adapters/grid'` |
| Direct Nivo import in feature | `import { LineChart } from '#shared/adapters/charts'` |
| Tailwind classes with hardcoded colors | Use CSS variable tokens (`text-foreground`, `bg-surface`) |
| Business logic in component body | Move to `model/` (pure fn) |
| API call in component body | TanStack Query hook in `api/` |
| Inline objects in JSX props | Extract to const or `ui/constants/` |
| `useEffect` for derived state | Compute in render or in hook body |
| Skipping index.ts public API | Every feature exports ONLY through index.ts |

# Security

## Data Anonymization — Non-Negotiable

- Raw CSV data NEVER leaves the browser. Parsing and anonymization happen client-side (papaparse, in-memory).
- Only anonymized data is sent to the backend for storage as transactions.
- AI adapters receive ONLY: `(transaction_id, anonymized_title, amount)` — nothing else.
- No account numbers or personal identifiers in any backend storage or logs.

**Categorization rules are NOT subject to anonymization.** Rules are user-created keyword mappings (e.g., `BIEDRONKA → Groceries`). These are intentional user input, not raw CSV data. They live in the `categorization_rules` table and are owned by the user's workspace.

## AI Adapter Contracts

- AI agents NEVER access the database directly — always through Command/Query handlers.
- NestJS prepares anonymized, aggregated datasets — AI gets a ready-made package.
- AI output passes through the same policy layer before reaching the user.
- AI adapters sit behind port interfaces (`CategorizationPort`, `InsightPort`) — swappable without touching domain logic.

## ABAC (Attribute-Based Access Control)

- Ownership check before ANY data access. No exceptions.
- `permissions` table exists from day one (even if only owner-level in MVP).
- Every query filters by workspace/user context — no global data access.
- Mapper Domain→DTO is the enforcement point for field-level access control.

## TypeScript Security Rules

- Strict TypeScript — no `any`, no unsafe assertions.
- Zod validation at EVERY system boundary (API input, CSV parsing output, AI adapter response).
- No `eval()`, `Function()`, or dynamic code execution.
- Parameterized queries only — never string interpolation in SQL.
- No secrets in code, config files committed to repo, or environment variable defaults.

## API Security

- JWT + refresh tokens for authentication.
- Rate limiting on all public endpoints.
- Input validation (Zod) before any processing.
- No sensitive data in error responses — generic error messages to client, detailed logs server-side only.
- CORS restricted to known origins.

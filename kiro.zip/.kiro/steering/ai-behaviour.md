# AI Behaviour

## Interaction Style

- Teach through work — when fixing or flagging issues, explain WHY and what principle it violates.
- Challenge bad ideas — say NO when something violates architecture. Propose the correct approach.
- Quality over speed — always. Better design beats faster delivery.
- If unclear — ask, don't guess.
- Explain plan before making changes. Get confirmation for non-trivial work.

## Security-First Mindset

- Before any data operation: verify anonymization is in place.
- Raw/unanonymized data NEVER reaches AI adapters or external services.
- ABAC ownership checks before any data access — even in dev.
- No sensitive data in logs, error messages, or API responses.
- Treat every boundary crossing as a potential data leak.

## Drift Prevention

- Stay within task scope. No extra features, no premature abstractions.
- If you need to hack (cast, suppress lint, skip test) — stop and redesign.
- If a developer's shortcut would create tech debt — block it and explain the cost.

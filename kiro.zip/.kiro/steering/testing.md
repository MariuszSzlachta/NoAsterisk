# Testing

## Layer-Specific Strategy

| Layer | Test type | Mocking | What to assert |
|---|---|---|---|
| **Domain** | Pure unit tests | ZERO mocks | Entity behavior, invariants, value object logic |
| **Application** | Unit tests | Mock ports (interfaces) | Handler orchestration, correct port calls, error handling |
| **Infrastructure** | Integration tests | Real DB (test container) | Repository queries work, mappers produce correct shapes |
| **Presentation** | Contract / e2e tests | Mock application layer | Correct HTTP status, Zod validation rejects bad input, response shape |

## Rules

- Test behavior, not implementation. Assert on observable outcomes.
- If code behavior didn't change but test broke — the test is wrong.
- 3 categories per function: happy path, boundary, error path.
- Use `it.each` for multiple cases of the same assertion.

## Domain Tests — Zero Mocks, Pure Logic

```typescript
describe('SubBudget', () => {
  describe('applyTransaction', () => {
    it('reduces balance by transaction amount', () => {
      const budget = new SubBudget({ balance: Money.of(1000, 'PLN') });
      budget.applyTransaction(Money.of(200, 'PLN'));
      expect(budget.remaining).toEqual(Money.of(800, 'PLN'));
    });

    it('throws when balance insufficient', () => {
      const budget = new SubBudget({ balance: Money.of(100, 'PLN') });
      expect(() => budget.applyTransaction(Money.of(200, 'PLN'))).toThrow();
    });
  });
});
```

## Application Tests — Mocked Ports

```typescript
describe('CategorizeTransactionHandler', () => {
  const suggestMock = jest.fn<Promise<CategorySuggestion>, [AnonymizedTransaction]>();
  const mockPort: CategorizationPort = { suggest: suggestMock };
  const handler = new CategorizeTransactionHandler(mockPort);

  it('returns AI suggestion when no rule matches', async () => {
    suggestMock.mockResolvedValue({ category: 'Groceries', confidence: 0.9 });
    const result = await handler.execute(command);
    expect(result.category).toBe('Groceries');
  });
});
```

## Infrastructure Tests — Real DB

```typescript
describe('TransactionRepository', () => {
  let repo: PostgresTransactionRepository;
  // Setup: test DB container, run migrations

  it('persists and retrieves transaction', async () => {
    const entity = buildTransaction({ title: 'BIEDRONKA' });
    await repo.save(entity);
    const found = await repo.findById(entity.id);
    expect(found).toEqual(entity);
  });
});
```

## Presentation Tests — HTTP Contract

```typescript
describe('POST /transactions/import', () => {
  it('returns 400 when Zod validation fails', async () => {
    const response = await request(app).post('/transactions/import').send({});
    expect(response.status).toBe(400);
  });

  it('returns 201 with valid anonymized data', async () => {
    const response = await request(app)
      .post('/transactions/import')
      .send(validImportPayload);
    expect(response.status).toBe(201);
  });
});
```

## DO NOT Test

- Simple getters/setters without logic
- Type definitions, interfaces, enums
- Framework behavior (NestJS DI wiring, React rendering engine)
- That a function exists — TypeScript guarantees this

## Test Data — Builders

```typescript
// buildTransaction.ts
const defaults: TransactionProps = {
  id: 'tx-001',
  amount: Money.of(100, 'PLN'),
  anonymizedTitle: 'GROCERY_STORE',
  date: new Date('2025-01-15'),
};

export const buildTransaction = (overrides?: Partial<TransactionProps>): Transaction =>
  new Transaction({ ...defaults, ...overrides });
```

Use builders. Never inline object literals for test data.

## Mocking

- `jest.spyOn` over `jest.mock()` — type-safe, explicit.
- Mock only port interfaces and external boundaries.
- Domain tests have ZERO mocks — pure logic, pure assertions.
- `afterEach`: `jest.clearAllMocks()`
- `afterAll`: `jest.restoreAllMocks()`

## Naming

Pattern: `does/should [action] when/if/for [condition]`

```typescript
it('returns error when amount is negative', () => {});
it('categorizes transaction when exact rule matches', () => {});
it('falls back to AI when no rule matches', () => {});
```

## File Placement

- Unit: `file.spec.ts` — next to source file
- Integration: `__tests__/` directory within module
- E2E: `test/` at project root

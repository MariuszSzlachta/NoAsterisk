# Clean Architecture

## Backend — NestJS Hexagonal (Ports & Adapters)

### Layer Structure per Module

```
src/modules/{feature}/
  domain/
    entities/            ← Rich models with business logic
    value-objects/       ← Money, DateRange, etc.
    ports/               ← Interfaces for external deps (AI, repos)
    events/              ← Domain events (optional)

  application/
    commands/            ← Write operations (handler + command DTO)
    queries/             ← Read operations (handler + query DTO)
    mappers/             ← Domain ↔ Response DTO

  infrastructure/
    repositories/        ← PostgreSQL implementations of domain ports
    adapters/            ← AI adapter implementations (Claude, etc.)
    mappers/             ← Persistence ↔ Domain Entity

  presentation/
    controllers/         ← NestJS controllers (thin — validate + delegate)
    dto/                 ← Zod schemas for request validation
```

### Dependency Rule

```
presentation → application → domain
                    ↓
             infrastructure → domain
```

- Domain imports NOTHING. Zero framework dependencies.
- Application depends on domain ports (interfaces), never on infrastructure directly.
- Infrastructure implements domain ports.
- Presentation validates input (Zod) and delegates to application layer.

### Mappers at Every Boundary

```
PostgreSQL row
   ↓ [infrastructure/mappers: Persistence → Domain Entity]
Domain Entity
   ↓ [application/mappers: Domain → Response DTO]  ← ABAC filtering here
Response DTO (HTTP contract)
```

```
Request DTO (validated by Zod)
   ↓ [presentation validates, passes to command/query]
Command/Query handler (application layer)
   ↓ [uses domain entities + ports]
Domain Entity
   ↓ [infrastructure/mappers: Domain → Persistence]
PostgreSQL row
```

No entity crosses a boundary without mapping. API schema change = 1 mapper change, nothing cascades.

### CQRS-lite

| | Command | Query |
|---|---|---|
| Does | Mutates state | Reads data |
| Flow | validate → execute domain logic → persist → return | fetch → map → return DTO |
| Handler | `@Injectable()` class | `@Injectable()` class |
| Location | `application/commands/` | `application/queries/` |

Plain `@Injectable()` handlers — no `@nestjs/cqrs` dependency. Controllers call handlers directly via DI.

AI agents always operate through Command (when writing rules) or Query (when reading aggregates) — never direct DB access.

### Ports (Domain Interfaces)

```typescript
// domain/ports/categorization.port.ts
export interface CategorizationPort {
  suggest(input: AnonymizedTransaction): Promise<CategorySuggestion>;
}

// infrastructure/adapters/claude-categorization.adapter.ts
@Injectable()
export class ClaudeCategoryAdapter implements CategorizationPort { ... }
```

Today Claude, tomorrow another model — zero changes in domain or application logic.

### Domain — Rich Models

Entities MUST have behavior:
- Business methods (e.g., `transaction.assignCategory()`, `subBudget.canAfford()`)
- Invariant guards (reject invalid state in constructor/factory)
- State transitions
- Validation rules

If entity has only getters — it's anemic. Fix it.

Value Objects for domain concepts:
- `Money` (amount + currency, arithmetic operations)
- `DateRange` (start/end, overlap detection)
- `TransactionTitle` (anonymized, validated)

### Anti-Patterns

| ❌ Doing this | ✅ Do this instead |
|---|---|
| Business logic in controller | Move to domain entity or command handler |
| Repository returns DTO | Repository returns Domain Entity via mapper |
| Domain entity imports NestJS decorators | Domain is framework-free |
| Command handler calls AI directly | Inject port interface, adapter implements it |
| Controller builds SQL queries | Repository encapsulates all persistence |
| Raw entity in API response | Map to DTO in application layer |
| AI adapter reads from DB | Handler prepares data, passes to adapter |

### Architectural Exceptions

When a rule is intentionally violated (e.g., accepted cross-module coupling), document inline:

```typescript
// ARCH-EXCEPTION: [rule violated] — [reason] — [planned resolution]
// Example:
// ARCH-EXCEPTION: cross-module import — sync call to AutoCategorizeHandler,
//   event-driven planned in Phase 4 (BUD-89)
```

- `arch-lint.sh` respects `ARCH-EXCEPTION: global-scope` for repository ports without `workspaceId`.
- Review agent: do NOT re-flag comments with `ARCH-EXCEPTION` unless the planned resolution ticket is overdue.
- Every exception MUST reference a ticket or explicit "accepted permanently" statement.



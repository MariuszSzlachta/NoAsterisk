# Clean Code

## Naming — Intent Over Implementation

### Functions — verb + noun

```typescript
// ✅
mapDtoToTransaction(dto)
calculateBudgetRemaining(subBudget)
validateImportProfile(profile)
anonymizeTransaction(raw)

// ❌ Vague
processData(dto)
handle(budget)
check(profile)
```

### Booleans — always predicate

Prefix: `is`, `has`, `should`, `can`, `was`.

```typescript
const isAnonymized = transaction.title !== rawTitle;
const canAfford = subBudget.canAfford(amount);
const hasMatchingRule = rules.some(r => r.matches(title));
```

### Pattern names in identifiers

| Pattern | Name convention | Example |
|---|---|---|
| Factory | `create*` | `createTransactionFromCsv` |
| Mapper | `map*To*` | `mapPersistenceToEntity` |
| Type guard | `is*` / `has*` | `isValidTransaction` |
| Port | `*Port` | `CategorizationPort` |
| Adapter | `*Adapter` | `ClaudeCategoryAdapter` |
| Command handler | `*Handler` | `ImportCsvHandler` |

## SOLID

### SRP — One reason to change

Name ONE responsibility. If you need "and" — split it.

```typescript
// ❌ Does too much
class TransactionService {
  import() { ... }
  categorize() { ... }
  generateInsights() { ... }
  sendNotification() { ... }
}

// ✅ Each has one responsibility
class ImportCsvHandler { ... }
class CategorizeTransactionHandler { ... }
class GenerateInsightsHandler { ... }
```

### OCP — Add, don't modify

```typescript
// ✅ Record<Enum, Handler> — add new matcher by adding entry
const MATCHERS: Record<MatcherType, CategorizationMatcher> = {
  [MatcherType.Contains]: new ContainsMatcher(),
  [MatcherType.Exact]: new ExactMatcher(),
};

// ❌ if/else chain — every new type modifies this
if (type === 'contains') { ... }
else if (type === 'exact') { ... }
```

### DIP — Depend on abstractions

Domain defines port interfaces. Infrastructure implements them. Application orchestrates via interfaces.

```typescript
// ✅ Handler depends on port (interface) via Symbol token
constructor(
  @Inject(CATEGORIZATION_PORT) private readonly categorizationPort: CategorizationPort,
) {}

// ❌ Handler depends on concrete adapter
constructor(private readonly claude: ClaudeService) {}
```

### ISP — Pass only what's needed

```typescript
// ❌ Consumer needs only id + title, receives entire entity
categorize(transaction: Transaction): Promise<Category>;

// ✅ Slim interface — only what AI needs
categorize(input: { id: string; anonymizedTitle: string; amount: number }): Promise<CategorySuggestion>;
```

## Tell, Don't Ask

Don't inspect entity state externally. Tell the entity what you need.

```typescript
// ❌ ASK — decision logic lives outside entity
if (subBudget.balance >= transaction.amount && subBudget.isActive) {
  subBudget.balance -= transaction.amount;
}

// ✅ TELL — entity owns the decision
subBudget.applyTransaction(transaction); // throws if can't afford
```

## Composition Over Inheritance

- Prefer function composition and delegation.
- NestJS: use DI + interfaces, not abstract base classes (unless sharing invariant logic).
- React: compose via hooks and component composition.

## DRY — Rule of Three

Don't extract after the first duplicate. Extract after the THIRD occurrence — by then you see the real pattern.

## Dependency Injection in NestJS

```typescript
// modules/transactions/tokens.ts
export const CATEGORIZATION_PORT = Symbol('CATEGORIZATION_PORT');
export const TRANSACTION_REPO = Symbol('TRANSACTION_REPO');

// ✅ Port injected via NestJS DI with Symbol token
@Injectable()
export class CategorizeTransactionHandler {
  constructor(
    @Inject(CATEGORIZATION_PORT) private readonly ai: CategorizationPort,
    @Inject(TRANSACTION_REPO) private readonly repo: TransactionRepositoryPort,
  ) {}
}

// Module wires the implementation
@Module({
  providers: [
    { provide: CATEGORIZATION_PORT, useClass: ClaudeCategoryAdapter },
    { provide: TRANSACTION_REPO, useClass: PostgresTransactionRepository },
  ],
})
export class TransactionsModule {}
```

## Anti-Patterns — Stop If You See These

| ❌ Doing this | ✅ Do this instead |
|---|---|
| Business logic in controller | Domain entity method or command handler |
| Fat service doing everything | Split into focused handlers per operation |
| Raw string where domain concept exists | Value Object (Money, TransactionTitle) |
| if/else on type field | Record<Enum, Handler> or strategy pattern |
| Entity with only getters | Add behavior — or it's a DTO, not an entity |
| AI adapter knowing about DB schema | Handler maps data, passes anonymized input to port |
| Validation in controller | Zod schema in DTO + domain invariants in entity |
| Try/catch swallowing errors silently | Typed error handling with proper logging |

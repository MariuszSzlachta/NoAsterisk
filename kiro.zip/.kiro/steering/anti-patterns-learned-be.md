# Anti-Patterns — Learned from Reviews

These exact mistakes were made in this project. NEVER repeat them.

---

## AP-1: Domain enum in Response DTO

```typescript
// ❌ Couples API contract to domain internals
import { TransactionType } from '@transactions/domain/entities/transaction.entity';
interface TransactionResponseDto { type: TransactionType; }

// ✅ DTO owns its contract — string literals
interface TransactionResponseDto { type: 'income' | 'expense'; }
```

**Why:** Domain enum rename would cascade to API consumers. DTO is a boundary — it defines its own types.

---

## AP-2: z.nativeEnum(DomainEnum) in Zod schema

```typescript
// ❌ Presentation layer importing from domain
type: z.nativeEnum(TransactionType)

// ✅ Presentation defines own contract
type: z.enum(['income', 'expense'])
```

**Why:** Presentation layer must not import from domain. Zod schema IS the API contract — independent from domain model.

---

## AP-3: Constructor without invariants

```typescript
// ❌ Constructor accepts anything, create() validates
constructor(id, amount, type) { this.id = id; this.amount = amount; this.type = type; }
static create(props) { validate(props); return new Transaction(props); }

// ✅ Constructor ALWAYS validates — no invalid instance can exist
constructor(id: string, amount: Money, type: TransactionType) {
  if (!id) throw new DomainError('ID is required');
  if (amount.isNegative()) throw new DomainError('Amount must be positive');
  this.id = id; this.amount = amount; this.type = type;
}
```

**Why:** Reconstitution from DB goes through constructor. If constructor doesn't validate, corrupted data creates invalid entity silently.

---

## AP-4: Factory create() accepts id parameter

```typescript
// ❌ Leaks identity responsibility to caller
static create({ id?: string, amount, type }) { return new Transaction(id ?? uuid(), ...); }

// ✅ create() = new identity. Constructor = reconstitution.
static create({ amount, type }) { return new Transaction(uuid(), amount, type, new Date()); }
constructor(id: string, amount: Money, type: TransactionType, createdAt: Date) { /* validates */ }
```

**Why:** Entity owns its identity at creation time. External ID injection is only for reconstitution from persistence (via infrastructure mapper).

---

## AP-5: Repository method without workspace scope

```typescript
// ❌ Global query — cross-workspace data leak
existsByContentHash(hash: string): Promise<boolean>;

// ✅ Always scope by workspace
existsByContentHash(workspaceId: string, hash: string): Promise<boolean>;
```

**Why:** Every query MUST be workspace-scoped. Even "existence checks" can leak information across tenants.

---

## AP-6: Cross-module import for shared utility

```typescript
// ❌ Categories importing from Transactions internals
import { ZodValidationPipe } from '@transactions/presentation/zod-validation.pipe';

// ✅ Shared utilities live in @shared/
import { ZodValidationPipe } from '@shared/presentation/zod-validation.pipe';
```

**Why:** Modules are independent deployment units. Cross-module import = hidden coupling = cascading changes.

---

## AP-7: Controller doing business logic

```typescript
// ❌ Controller orchestrating multi-step use case
@Post()
async import(@Body() dto) {
  const violations = this.piiService.validate(dto.rows);      // step 1
  const cleanRows = dto.rows.filter(r => !hasViolation(r));   // step 2
  const result = await this.handler.execute({ rows: cleanRows }); // step 3
  if (violations.length) return { status: 'partial', ... };   // step 4
}

// ✅ Controller: validate → delegate → respond
@Post()
async import(@Body() dto) {
  const result = await this.handler.execute(dto);
  return this.mapToResponse(result);
}
```

**Why:** Business logic in controller means every new entry point (CLI, cron, queue) must duplicate it. One handler orchestrates — controller is just HTTP adapter.

---

## AP-8: Immutable update loses fields

```typescript
// ❌ update() forgets to propagate contentHash, importBatchId
update(props): Transaction {
  return new Transaction(this.id, props.amount ?? this.amount, /* ...missing fields... */);
}

// ✅ ALL fields propagated in every state-change method
update(props): Transaction {
  return new Transaction(
    this.id, props.amount ?? this.amount, ...,
    this.contentHash, this.importBatchId, // ← never forget these
  );
}
```

**Why:** Immutable entity pattern means EVERY method creating a new instance must carry ALL state. Lost field = lost data = broken deduplication/linking.

---

## AP-9: Type guard defined in infrastructure instead of domain

```typescript
// ❌ Infrastructure defines domain concept validation
// infrastructure/mappers/transaction.mapper.ts
function isTransactionType(value: string): value is TransactionType { ... }

// ✅ Domain owns its concepts — infrastructure imports them
// domain/value-objects/transaction-type.guard.ts
export function isTransactionType(value: string): value is TransactionType { ... }
```

**Why:** If it validates a domain concept, it belongs to domain. Infrastructure imports from domain, never defines domain logic.

---

## AP-10: Duplicate provider across modules (separate instances)

```typescript
// ❌ ImportsModule creates its own repo instance — invisible to TransactionsModule
@Module({ providers: [{ provide: TRANSACTION_REPOSITORY, useClass: InMemoryTransactionRepository }] })
export class ImportsModule {}

// ✅ Import the module that owns the provider
@Module({ imports: [TransactionsModule] }) // TransactionsModule exports TRANSACTION_REPOSITORY
export class ImportsModule {}
```

**Why:** Two in-memory instances = data written by import is invisible to queries. Symptoms: "transactions disappear after import."

---

## AP-11: Email validation regex without minimum TLD length

```typescript
// ❌ Accepts invalid TLDs like a@b.c
/^[^\s@]+@[^\s@]+\.[^\s@]+$/

// ✅ Require at least 2-char TLD
/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
```

**Why:** Single-char TLDs don't exist. Permissive regex lets through clearly invalid emails that fail silently downstream (email sending, uniqueness checks).

---

## AP-12: Globally unique field without documenting scope decision

```typescript
// ❌ Port with no comment — reader assumes workspace-scoped (project default)
export interface UserRepository {
  findByEmail(email: string): Promise<User | undefined>;
}

// ✅ Explicit documentation of scope decision
/**
 * Email is globally unique (not workspace-scoped) — standard SaaS pattern.
 */
export interface UserRepository {
  findByEmail(email: string): Promise<User | undefined>;
}
```

**Why:** This project defaults to workspace-scoped queries (AP-5). Any deviation MUST be documented at the port level, otherwise next developer adds `workspaceId` param "to be consistent" and breaks login flow.

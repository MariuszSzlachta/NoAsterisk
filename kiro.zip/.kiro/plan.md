# Budget App — Plan Koncepcyjny

## Geneza i problem

Aplikacja powstaje jako odpowiedź na ograniczenia prowadzenia budżetu w Apple Numbers:
- ręczne wprowadzanie danych — czasochłonne i podatne na błędy
- dane nie są aktualne — płatności kartą umykają, wydatki "znikają"
- brak automatyzacji importu z banków
- brak wglądu w sub-budżety i trendy w czasie rzeczywistym

Docelowo aplikacja ma być produktem SaaS sprzedawanym innym użytkownikom, a nie tylko narzędziem prywatnym — co wpływa na decyzje architektoniczne od samego początku.

---

## Co to za aplikacja

Webowa aplikacja do zarządzania budżetem osobistym i rodzinnym z:
- importem danych z banków przez CSV (anonimizowanym po stronie klienta)
- automatyczną kategoryzacją transakcji przez reguły + AI jako fallback
- widokiem sub-budżetów, sald i trendów
- systemem uprawnień pozwalającym na współdzielenie budżetów między użytkownikami
- warstwą agentów AI do analizy, insightów i planowania budżetu

---

## Źródła danych

Trzy konta bankowe:
- konto firmowe
- konto osobiste
- konto żony

Każdy bank eksportuje CSV o innym formacie (różne kolumny, separatory, kodowania dat). Aplikacja obsługuje wiele formatów przez konfigurowalne profile importu.

---

## Flow danych — Import CSV

```
CSV z banku (lokalnie u usera)
   ↓
Upload do przeglądarki — parsowanie przez papaparse (w pamięci, nic nie leci na serwer)
   ↓
Profil importu (auto-detect lub user wybiera bank) — mapowanie kolumn + reguły anonimizacji
   ↓
Anonimizacja warstwowa (in-browser):
   1. Automatyczna: regex strip IBAN, numery kart, PESEL, email, tel
   2. Per profil: hashowanie kontrahentów, usuwanie kolumn (saldo, nr konta)
   3. User review: ręczna edycja opisów w DataGrid
   ↓
DataGrid z edycją + smart batch edit:
   - user edytuje opis → system proponuje zmianę dla podobnych transakcji (side panel)
   - user przypisuje kategorie (ręcznie / batch)
   - opcja: "Zapisać jako regułę na przyszłość?" → tworzy categorization rule
   ↓
Content hash generowany PRZED anonimizacją (na froncie):
   SHA-256(transactionDate + amount + rawTitle + SHA-256(accountNumber))
   → hash leci razem z zanonimizowanymi danymi jako dedup key
   ↓
Chunking: front dzieli na paczki ~100-200 rekordów
   → każdy chunk = osobny POST /transactions/import
   → wszystkie chunki mają wspólny batchId (UUID, generowany na froncie)
   ↓
Backend: walidacja (Zod + guardrails anty-PII) → zapis → dedup po content hash
```

**Kluczowe zasady:**
- Surowy CSV nigdy nie trafia na serwer ani do AI
- Content hash jest irreversible — przechowywanie go na serwerze nie łamie zasady bezpieczeństwa
- Serwer nie może przeliczyć hasha (nie ma surowych danych) — ufa klientowi (akceptowalny trade-off: user sabotowałby tylko własną deduplikację)

### Smart batch edit (UX pattern)

```
User edytuje pole w DataGrid (np. opis transakcji)
   ↓
System szuka w bieżącym imporcie transakcji z tym samym oryginalnym opisem/kontrahentem
   ↓
Side panel: "Znaleziono N podobnych. Zmienić też?"
   - podgląd listy dopasowanych transakcji
   - [Tak, zmień wszystkie] / [Nie, tylko tę]
   ↓
Opcjonalnie: "Zapisać jako regułę kategoryzacji?"
   - Tak → POST rule: keyword → kategoria (po zatwierdzeniu importu)
```

Cały flow smart edit dzieje się in-memory na froncie — backend dostaje gotowe, czyste dane.

---

## Profile importu

Mapowanie kolumn per bank zapisane w bazie danych (nie w localStorage), bo aplikacja będzie multi-user i profile mają być dostępne z każdego urządzenia.

```
import_profiles
- id
- workspace_id
- bank_name
- column_mapping (jsonb)         ← która kolumna CSV = date/amount/title/counterparty
- sensitive_columns (jsonb)      ← które kolumny usunąć przy anonimizacji
- anonymization_rules (jsonb)    ← per-pole: hash | remove | keep | regex_strip
- parser_config (jsonb)          ← delimiter, encoding, date_format, decimal_separator
- created_at
```

Przy kolejnym imporcie z tego samego banku system rozpoznaje nagłówki CSV i proponuje zapisany profil — zero ręcznej konfiguracji za każdym razem.

### Różnice między bankami (realne przykłady)

| | Bank A (ING-style) | mBank |
|---|---|---|
| Format | CSV z headerami, ładne kolumny | Tekst/CSV z operacjami wbitymi w opis |
| Kontrahent | Osobne pole (hashowalny) | Wbity w description (np. "MD SERWIS M. GROCHULSK") |
| Konto źródłowe | Brak / osobna kolumna | W opisie ("6011 ... 4820") |
| Kategoria | Podana przez bank | Podana przez bank |
| ID operacji | Unikalne, hashowalny | Może nie istnieć |
| Dane wrażliwe | Mało — głównie nr ref | Nazwiska, adresy w opisach |

**Wniosek:** profil importu to nie tylko "column mapping" — to pełna definicja parsera + reguł anonimizacji per pole.

---

## Kategoryzacja transakcji

### Silnik reguł (podstawa)

Pattern Strategy / Chain of Responsibility — plugowalne matchery:
- `ContainsMatcher` — czy tytuł transakcji zawiera słowo kluczowe
- `ExactMatcher` — dokładne dopasowanie nazwy
- `RegexMatcher` — zaawansowane wzorce (do dodania później)

Reguły zarządzane przez panel admina:

| Słowo kluczowe | Kategoria | Sub-budżet | Priorytet |
|---|---|---|---|
| BIEDRONKA | Spożywcze | Dom | 1 |
| ŻABKA | Spożywcze | Dom | 1 |
| PHU ANNA KOWALSKA | Spożywcze | Dom | 2 |

### AI jako fallback

Gdy reguła nie pasuje → transakcja trafia do kolejki "nierozpoznanych" → user odpala AI na żądanie (batch, nie per transakcja automatycznie).

**Kontrakt z AI:**
- AI dostaje: `(transaction_id, anonymized_title, amount)` — tylko zanonimizowane dane
- AI zwraca: `(transaction_id, suggested_category, confidence)`
- User zatwierdza lub poprawia → wynik zapisuje się jako nowa reguła w panelu admina

**AI jako jednorazowy detektyw, nie silnik działający przy każdej transakcji.** Raz ustalone mapowanie merchant → kategoria żyje jako reguła w bazie i nie wymaga kolejnych wywołań AI.

### Cachowanie AI

Wyniki kategoryzacji AI są cachowane — ten sam zanonimizowany tytuł nie generuje kolejnego wywołania API. Cache na poziomie command handlera.

---

## Agenci AI (faza 2+)

Trzy poziomy złożoności:

**Poziom 1 — Kategoryzacja** (jak wyżej — reaktywna, prosta, stateless)

**Poziom 2 — Analiza i insighty**
Agent dostaje zagregowane dane (sumy per kategoria per miesiąc, nie surowe transakcje) i generuje obserwacje: trendy, przekroczenia, anomalie.

**Poziom 3 — Planer budżetu**
Agent proponuje realokacje między sub-budżetami na podstawie historii i celów usera.

### Zasady bezpieczeństwa agentów

- Agent **nigdy** nie ma bezpośredniego dostępu do bazy danych
- Agent zawsze działa przez Command/Query handler
- NestJS przygotowuje zanonimizowany, zagregowany dataset — agent dostaje gotowy pakiet
- Output agenta wraca przez tę samą warstwę policy przed dotarciem do usera
- Skille per command handler — różne handlery przekazują różny, wyspecjalizowany kontekst
- AI jako wymienny adapter za interfejsem portu (`CategorizationPort`, `InsightPort`) — dziś Claude, jutro inny model, zero zmian w logice domenowej

**Tryb: na żądanie (nie proaktywny) — user inicjuje analizę, agent nie działa w tle samodzielnie** (przynajmniej do czasu gdy produkt dojrzeje).

---

## Model uprawnień — ABAC

**Decyzja: ABAC (Attribute-Based Access Control), nie RBAC.**

RBAC jest zbyt gruboziarnisty dla tego use case'u. ABAC pozwala na:
- Żona widzi sub-budżet "Dom", ale nie widzi konta firmowego
- Współdzielenie pojedynczego sub-budżetu ze współlokatorem bez dostępu do reszty
- Różne poziomy dostępu: `owner | edit | view`
- Możliwe rozszerzenie: permission nie tylko na zasób, ale i na poziom szczegółowości (np. "widzi agregaty, ale nie pojedyncze transakcje")

```
permissions
- user_id
- resource_type  (sub_budget | account | workspace)
- resource_id
- actions        (read, write, delete — array)
- granted_by
- conditions?    (opcjonalnie — granulacja danych)
```

**ABAC nie jest implementowane w MVP** — ale architektura zostawia dla niego miejsce od początku, żeby uniknąć bolesnej migracji z RBAC później.

### Co to oznacza praktycznie już teraz

- Nie hardkodować `user_id` jako jedynego właściciela wszędzie — tabela `permissions` istnieje od początku, nawet jeśli na starcie ma tylko jeden rekord per zasób (owner, pełny dostęp)
- Sub-budżet jako pierwszorzędny obywatel z własnym ID i relacją do ownera — niezależny strukturalnie od workspace
- Pole `access_level: owner | edit | view` w modelu od początku (zamiast boolean)

---

## Multi-tenancy i użytkownicy

Aplikacja od początku projektowana jako multi-user SaaS:
- Auth: JWT + refresh tokens (np. passport-jwt w NestJS)
- Każdy user ma swoje: konta źródłowe, sub-budżety, reguły kategoryzacji, profile importu
- `user_id` / `workspace_id` jako foreign key wszędzie + Row Level Security lub filtrowanie globalne w NestJS

### Model workspace (pod przyszłe współdzielenie)

```
workspaces
- id
- name  (np. "Rodzina Kowalskich")

workspace_members
- workspace_id
- user_id
- role  (owner / member)

budgets, transactions, sub_budgets → należą do workspace_id, nie user_id
```

To rozwiązuje przypadek "Ty + żona" i jest gotowe pod sprzedaż innym partiom/rodzinom/firmom.

---

## Stack technologiczny

### Frontend
- **Vite** — bundler
- **React + TypeScript**
- **Zustand** — state management
- **papaparse** — parsowanie CSV w przeglądarce (in-memory)
- **TanStack Table** — DataGrid do podglądu i mapowania CSV (alternatywnie ag-grid-community)

### Backend
- **NestJS + TypeScript**
- **PostgreSQL**
- **Drizzle ORM** — typesafe SQL, schema osobno od encji domenowych, plain objects idealne pod mapper pattern
- **Zod** — walidacja DTO i runtime

---

## Architektura backendu

**Modular Monolith + Hexagonal-lite (Ports & Adapters) z elementami DDD**

Nie pełne DDD (zbyt dużo ceremonii na tym etapie), nie MVC (zbyt płaskie). Środek: czyste warstwy domenowe z portami dla zewnętrznych zależności (AI, baza).

### Kluczowe zasady architektury:

**Layering z mapperami na każdej granicy — zero leaków:**

```
Persistence (Postgres row)
   ↓ [mapper: Persistence → Domain Entity]
Domain Entity (logika biznesowa, żyje tylko w domain/ + application/)
   ↓ [mapper: Domain → DTO]  ← tu też filtr ABAC
DTO (kontrakt HTTP)
   ↓ [mapper: DTO → ViewModel]  ← po stronie frontu
ViewModel (UI — widoki + hooki)
```

**CQRS-lite:**
- Command = operacja zmieniająca stan (import CSV, zatwierdzenie kategorii, dodanie reguły)
- Query = odczyt bez efektów ubocznych (insighty agenta, podsumowanie budżetu)

---

## Import Batch i deduplikacja

### Problem

CSV z banku nie ma unikalnych ID transakcji. User może przypadkowo zaimportować ten sam plik dwa razy, albo pliki z nakładającymi się zakresami dat (styczeń-marzec, potem luty-kwiecień).

### Rozwiązanie: dwupoziomowa deduplikacja

**Poziom 1 — Content hash per wiersz (primary dedup)**

Front generuje hash z surowych danych (przed anonimizacją):
```
contentHash = SHA-256(transactionDate + amount + rawTitle + SHA-256(accountNumber))
```

**Poziom 2 — Batch hash (early-return)**
```
batchHash = SHA-256(sorted(contentHashes[]))
```

### Model danych

```
import_batches
- id (UUID, generowany na froncie)
- workspace_id
- batch_hash (unique per workspace)
- source_filename (opcjonalnie)
- total_rows / saved_rows
- status (Pending → InProgress → Complete/PartiallyRejected)
- imported_at / completed_at

transactions
- ...existing fields...
- import_batch_id (FK → import_batches, nullable)
- content_hash (unique per workspace)
```

---

## Walidacja anty-PII po stronie serwera

Backend stosuje zaawansowany silnik walidacji z feedback loop:

```
Front: wysyła chunk → Backend: walidacja anty-PII
  ├─ ALL OK → 201 { status: 'accepted', saved: N }
  └─ PARTIAL REJECT → 207 { status: 'partial', saved: N, rejected: [...] }
       → Front: pokazuje odrzucone → User poprawia → retry
```

---

## Co odkładamy na później (nie MVP)

- ABAC implementacja (architektura gotowa, kod nie)
- Współdzielenie sub-budżetów między userami (edit/view)
- Proaktywny agent AI (działający w tle, powiadomienia)
- Planer budżetu (poziom 3 AI)
- Integracja bezpośrednia z API banków (PSD2) — na razie wystarczy CSV
- RegexMatcher w silniku reguł
- Aplikacja mobilna

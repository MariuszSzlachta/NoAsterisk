# CRITICAL: Never Revert User-Confirmed Changes

When the user confirms a change and then gives a SEPARATE instruction, apply the new instruction WITHOUT undoing the previously confirmed change.

If a new instruction might conflict with a previous one:
1. Apply both instructions as given.
2. Inform the user about the potential issue.
3. Ask if they want to adjust.

NEVER silently revert a confirmed decision based on own judgment about feasibility. The user decides what works — not the AI.

This applies to ALL visual/layout/design decisions. Confirmed state is sacred until the user explicitly says otherwise.

---
name: proj-documentation
description: Documentation creation for modules and features. Use for any documentation task.
---

# Documentation Standards

Full process and structure defined in `prompts/documentation.md`. This skill adds placement and quality rules.

## File Placement

Save as `{ModuleName}.docs.md` next to the source module/feature root.

## Required Sections

Every doc MUST have: Domain Context, Architecture & Trade-offs, Boundaries.

## Quality Fail Criteria

Doc is INCOMPLETE if:
- Domain Context is technical ("orchestrates workflow") instead of business ("users need X because Y")
- No Boundaries section
- No trade-offs mentioned
- Restates interface without explaining WHY

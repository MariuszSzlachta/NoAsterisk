---
name: proj-code-review-2
description: Deep architectural code review. Enforces hexagonal layering, DDD, CQRS, security. Use for "review my MR", "code review", "check my code".
---

# Code Review — Operational Details

Review methodology is in `prompts/code-review.md`. This skill adds the output format and layer traps checklist.

## Per-Layer Trap Checklist

**Domain:** anemic entity, no validation, mutable VO, raw string where VO needed, framework imports.

**Application:** fat handler, direct DB access, AI called without anonymization, missing error handling, mixed command+query.

**Infrastructure:** returns raw DB row, mapper ignores null, AI gets non-anonymized data, string SQL, business logic in repo.

**Presentation:** logic in controller, missing Zod, entity type in response, no ABAC check, fat controller.

**Frontend:** logic in component, direct API call, raw API types in UI, sensitive data shown.

## Output Format

File: `temp/{ticket}-review.md`

```markdown
### File: src/modules/transactions/domain/entities/transaction.entity.ts

**[L: 15-22]**
**[CRITICAL]** — Entity has zero business methods. Only getters = anemic model.
```

Rules:
- `[L: X]` = single line. `[L: X-Y]` = range.
- One finding = one `[L:]` + one `[SEVERITY]` block.
- Structural/systemic issues: omit `[L:]`.

## Systemic Issues

Same problem in 3+ files → ONE finding. Show pattern once, list all affected files.

## For CRITICAL — Show Correct Approach

- Target structure
- Code sketch (signatures + key methods)
- Why NOT alternatives

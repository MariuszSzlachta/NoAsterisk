---
name: proj-review-loop
description: Implement feature with automatic code review loop. Agent itself writes code, spawns code-review to check, fixes issues, repeats until clean. Per-bullet loop + architect review per phase. Use for "implement in loop", "feature with review loop", "build and review until clean", "review cycle", "implement + review loop".
---

# Review Loop — Implement → Review → Fix → Repeat

Orchestrates backend-developer/frontend-developer and code-review agents in a loop until 0 findings remain (including LOW severity).

## Policy: Zero Tolerance

- **ALL severities are fixed** — CRITICAL, MAJOR, MINOR, LOW. No exceptions.
- **0 tech debt** — nothing is "acceptable for now". Fix it or log a decision.
- **Decision log** — if something genuinely CANNOT be fixed now (external blocker, missing API, needs human decision), agent writes entry to `temp/decision-log.md` with: what, why, when to revisit, owner.
- Agent reads `temp/decision-log.md` at session start to know what's deferred.

## Phase-Gating — Mandatory

Agent reads `.kiro/development-plan.md` to understand current phase and its bullet tasks.

**Rules:**
1. Agent works on ONE phase at a time
2. Within a phase, agent executes bullets sequentially (1, 2, 3...)
3. After completing ALL bullets in a phase → agent STOPS and asks user for approval
4. Agent NEVER starts the next phase without explicit user confirmation
5. If user says "do phase 3" — agent does ONLY phase 3 bullets, then stops

**Flow per bullet:**
```
Read bullet task from development-plan.md
  → [LOOP START] Implement this ONE bullet (backend-developer or frontend-developer)
  → Review this ONE bullet (code-review)
  → If NEEDS_CHANGES → fix and re-review (max 3 rounds)
  → If APPROVED → [LOOP END] bullet done
  → Move to next bullet in same phase
```

After last bullet in phase — Architect Review Loop:
```
    → STOP. Report summary of all bullets.
    → [ARCHITECT LOOP START] (max 3 iterations)
    → Spawn architect agent for deep review of THE ENTIRE PHASE (all bullets combined)
    → Architect reviews holistic architecture, cross-cutting concerns, integration between bullets
    → Apply ALL issues from architect feedback (every severity including LOW)
    → If NEEDS_CHANGES → fix and spawn architect again for re-review
    → If APPROVED → [ARCHITECT LOOP END] phase verified and done
    → If max iterations reached → STOP, escalate to user
```
Then wait for user input — user may verify as human, propose next phase, or give other instructions.

**Architect spawning rule:** Same as code-review — YOU (the developer agent, BE or FE) spawn the architect sub-agent. You fix the issues yourself, architect only reviews.

## When To Use

- User asks for review loop / review cycle on a phase or feature
- User wants implementation + automatic quality gate
- NOT for single-shot implementation without review (use proj-development)
- NOT for standalone review (use proj-code-review-2)

## Identity Rule — The Orchestrator IS the Developer

**The agent running this skill IS the developer.** It does NOT spawn another developer agent.

- If the user invokes this skill with `frontend-developer` role → the agent itself writes FE code and spawns ONLY the `code-review` agent.
- If the user invokes this skill with `backend-developer` role → the agent itself writes BE code and spawns ONLY the `code-review` agent.
- When all bullets in phase done → the agent spawns `architect` agent for full-phase review (same spawning pattern as code-review)
**❌ NEVER spawn a developer sub-agent of the same role.** That's token waste — you ARE that developer.
**❌ NEVER spawn both a developer + code-review.** You implement, then spawn code-review to check your work.
**❌ NEVER spawn both a developer + architect.** You implement fixes, then spawn architect to re-review.

```
YOU (frontend-developer) → implement code yourself → spawn code-review → get feedback → fix yourself → repeat
YOU (backend-developer)  → implement code yourself → spawn code-review → get feedback → fix yourself → repeat

End of phase:
YOU (fe/be-developer) → spawn architect → get feedback → fix yourself → spawn architect again → repeat (max 3)
```

## Execution — Loop Per Bullet

The review loop runs **per single bullet** (not per phase). One bullet = one full loop until APPROVED.

```
FOR each bullet in current phase:
  ┌─────────────────────────────────────────────┐
  │  LOOP (max 3 iterations):                   │
  │    1. implement (backend/frontend-developer) │
  │       - Codes ONLY this one bullet          │
  │       - Includes prior review feedback      │
  │    2. review (code-review)                  │
  │       - Reviews changes for this bullet     │
  │       - NEEDS_CHANGES → back to implement   │
  │       - APPROVED → bullet done, exit loop   │
  └─────────────────────────────────────────────┘
  → Bullet approved. Next bullet.

ALL bullets in phase done:
  ┌──────────────────────────────────────────────────┐
  │  ARCHITECT LOOP (max 3 iterations):              │
  │    1. architect review (entire phase)            │
  │       - Reviews ALL changes across all bullets   │
  │       - Cross-cutting architecture concerns      │
  │    2. If NEEDS_CHANGES → YOU fix → re-review     │
  │    3. If APPROVED → phase done                   │
  └──────────────────────────────────────────────────┘
  → Phase approved. STOP. Report summary. Wait for user.
```

### Subagent stages (per bullet invocation)

```
The orchestrator (YOU) implements the code directly. Only code-review is a subagent:

  1. implement (YOU — the orchestrator agent)
     - You ARE the developer. Write the code yourself.
     - Codes ONLY the current bullet, nothing more
     - Follows proj-development standards (bottom-up, quality gates)
     - Fixes ALL issues from prior review — no skipping

  2. review (code-review — ONLY subagent spawned)
     - Reviews changes made for this bullet ONLY
     - Applies full proj-code-review-2 methodology
     - ALL severities count (LOW included)
     - Output: NEEDS_CHANGES (any finding exists) or APPROVED (zero findings)
     - If NEEDS_CHANGES → YOU fix it, then spawn code-review again (max 3 iterations)
```

## Prompt Templates

### implement stage

```
{task}

Context:
- Read .kiro/development-plan.md for the current phase and bullet context.
- Read temp/decision-log.md if it exists — know what's deferred and why.

If this is a revision after review feedback, the feedback is included above.
Fix ALL issues raised by the reviewer — every severity including LOW. Zero tolerance.

If you genuinely cannot fix something (external blocker, needs human decision):
- Add entry to temp/decision-log.md: [date] | [issue] | [reason cannot fix] | [when to revisit]
- Explain in your output why it's deferred

Follow proj-development standards:
- Build bottom-up: domain → application → infrastructure → presentation (BE) or domain → application → infrastructure → ui (FE)
- Run quality gates after each layer
- Follow steering files (clean-architecture, clean-code, security, anti-patterns-learned)

Verification:
- Backend: npx tsc --noEmit && npx eslint --fix src/ && npx jest --passWithNoTests
- Frontend: cd client && npx tsc --noEmit && npx eslint --fix src/ && npx jest --passWithNoTests

Output a summary of what you implemented/changed.
```

### review stage

```
Review code changes made for this bullet. Scope: files modified/created since the last approved bullet (use git diff --staged or git diff to identify changed files).

Apply full proj-code-review-2 methodology:

Backend files (src/modules/):
- Per-layer trap checklist (domain, application, infrastructure, presentation)
- Enforce hexagonal layering, DDD, CQRS, security

Frontend files (client/src/):
- FSD structure (pages vs features boundary)
- Per-layer trap checklist inside feature (domain, application, infrastructure, ui)
- Design system reuse, styling tokens, component patterns
- Check steering/code-quality/cq-react.md conventions

Both:
- Check anti-patterns from steering/anti-patterns-learned.md
- Check TypeScript conventions from steering/code-quality/cq-typescript.md
- Check if decision log entries are justified (not lazy deferrals)

ALL severities matter. A LOW finding = NEEDS_CHANGES. Zero tolerance policy.

Output format: list each finding with [SEVERITY] and file/line.

DECISION:
- If ANY finding exists (even LOW) → end with: NEEDS_CHANGES
- If truly zero findings → end with: APPROVED
```

### architect stage (end of phase)

```
Deep architectural review of the ENTIRE phase implementation. All bullets in this phase are now complete.

Scope: Review ALL files created/modified during this phase (use git diff against the branch base or the commit before this phase started).

Review focus:
- Cross-cutting architectural coherence between all bullets in this phase
- Hexagonal layering integrity (BE) / FSD layering integrity (FE)
- Domain model correctness — entities, value objects, invariants
- Integration points between components added in different bullets
- SOLID violations visible only at phase-level (not per-bullet)
- Security: anonymization boundaries, ABAC scoping, input validation completeness
- Missing edge cases or error handling that spans multiple bullets
- Consistency of naming, patterns, and conventions across the phase

Apply:
- steering/clean-architecture.md
- steering/clean-code.md
- steering/security.md
- steering/anti-patterns-learned.md
- steering/code-quality/cq-typescript.md
- steering/code-quality/cq-react.md (if FE)

ALL severities matter. A LOW finding = NEEDS_CHANGES. Zero tolerance policy.

Output format: list each finding with [SEVERITY] and file/line.

DECISION:
- If ANY finding exists (even LOW) → end with: NEEDS_CHANGES
- If truly zero findings → end with: APPROVED
```

## Loop Configuration

| Parameter | Value | Rationale |
|---|---|---|
| trigger (code-review) | `NEEDS_CHANGES` | Reviewer outputs this when any finding exists |
| target (code-review) | `implement` | Goes back to developer to fix |
| max_iterations (code-review) | 3 | Safety cap — if still broken after 3, escalate to human |
| trigger (architect) | `NEEDS_CHANGES` | Architect outputs this when any finding exists |
| target (architect) | `implement` | Goes back to developer to fix |
| max_iterations (architect) | 3 | Safety cap — if still broken after 3, escalate to human |

## Escalation

- **APPROVED (code-review)** → bullet done, move to next bullet in phase
- **APPROVED (architect)** → phase done, report to user, wait for approval
- **Max iterations reached (3 rounds, still NEEDS_CHANGES)** → STOP. Present findings to user. Ask for guidance. Do NOT proceed.

## Decision Log Format

File: `temp/decision-log.md`

```markdown
# Decision Log

| Date | Issue | Reason Deferred | Revisit When | Owner |
|---|---|---|---|---|
| 2026-06-24 | Missing PostgreSQL integration | In-memory phase, PG in post-MVP | Faza post-MVP | agent |
| 2026-06-24 | Rate limit tuning | Needs production traffic data | After launch | human |
```

Agent reads this at session start. If a deferred item's "revisit when" matches current phase — raise it.

## Example Invocation

User: "Zrób fazę 3 w loopie z review"

Agent:
1. Reads `.kiro/development-plan.md` → identifies Faza 3 bullets (11-16)
2. Reads `temp/decision-log.md` → checks deferred items
3. Bullet 11: implement → review → (fix loop if needed) → APPROVED ✓
4. Bullet 12: implement → review → (fix loop if needed) → APPROVED ✓
5. ...continues bullet by bullet...
6. Bullet 16: implement → review → APPROVED ✓
7. All bullets done → spawns architect for full-phase review
8. Architect: NEEDS_CHANGES → agent fixes → architect re-review → APPROVED ✓
9. Phase done → STOPS, reports summary, waits for user approval before Faza 4

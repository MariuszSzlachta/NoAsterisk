---
name: fe-retrospective
description: Analyze FE session logs and propose skill improvements. Use when asked for "retrospective", "review sessions", "co poprawić", "analyze performance", or after accumulating 5+ sessions.
---

# FE Retrospective — Data-Driven Skill Improvement

## When to Run

When user asks. Typically every 5-10 sessions. Never auto-run.

## Input

Read `temp/fe-session-log.jsonl` — all entries since last retrospective.

## Analysis Steps

### 1. Repeated Findings (→ new anti-pattern candidates)

```
Count each finding category across all sessions.
If a category appears in 3+ sessions → candidate for new AP-FE-XX.
```

Output:
```
🔴 REPEATED FINDINGS:
- inline_callback: 8 occurrences across 4/6 sessions → AP-FE-XX candidate
- hardcoded_color: 3 occurrences across 2/6 sessions → borderline
```

### 2. Ignored Skills (→ workflow enforcement needed)

```
Count skills_ignored across sessions.
If same skill ignored 3+ times → agent isn't following workflow.
```

Output:
```
⚠️ SKILLS IGNORED:
- fe-self-check: ignored in 4/6 sessions (correlated with higher review_rounds)
- fe-layer-model: ignored in 2/6 sessions
```

### 3. Review Round Trend (→ overall quality trajectory)

```
Calculate average review_rounds over time.
Rising = problem. Falling = improvement. Stable high = systemic issue.
```

Output:
```
📊 REVIEW ROUNDS:
- Sessions 1-3 avg: 3.2 rounds
- Sessions 4-6 avg: 1.8 rounds
- Trend: ↓ IMPROVING
```

### 4. Quality Gate First-Pass Rate

```
Percentage of sessions where fe-quality-gate.sh passed first try.
```

Output:
```
🚦 QUALITY GATE FIRST-PASS: 2/6 (33%) — needs improvement
```

### 5. Scope Creep Incidents

```
Count scope_creep: true sessions.
```

### 6. Duration vs Complexity Correlation

```
Look for sessions with high duration + low layers_touched = inefficiency signal.
```

## Proposals Format

After analysis, output CONCRETE proposals. Do NOT apply them:

```
## Proposed Changes (awaiting approval)

### New Anti-Patterns
1. [ ] Add AP-FE-11: [description] — appeared in X/Y sessions
   File: steering/anti-patterns-learned-fe.md

### Skill Strengthening
2. [ ] fe-self-check: add "MANDATORY: run fe-layer-check.sh" reminder at top
   File: .kiro/skills/frontend/fe-self-check/SKILL.md
3. [ ] fe-layer-ui: add explicit "no inline callbacks" check with example
   File: .kiro/skills/frontend/fe-layer-ui/SKILL.md

### Workflow Changes
4. [ ] fe-dev.md: make layer-check.sh call explicit after each layer (not optional)
   File: .kiro/prompts/fe-dev.md

### Skills to Consider Adding
5. [ ] New skill: fe-tailwind-tokens — dedicated cheatsheet for token names
```

## Rules

- **Propose, never apply.** User approves each change individually.
- **Data-backed only.** Every proposal cites session numbers/counts.
- **Prioritized.** Most impactful (highest frequency) first.
- **Actionable.** Each proposal = specific file + specific change. Not vague "improve X".
- **Track retrospective date.** After approval, add note to log: `{"type":"retrospective","date":"...","applied":[1,2,3],"rejected":[4,5]}`

---
name: fe-self-check
description: Per-layer self-check checklists for the frontend developer agent. Execute after writing each FE layer. Use after writing model/, api/, store/, or ui/ code.
---

# FE Self-Check — Execute After Each Layer

Run the section matching the layer you just wrote. ALL items must pass. If any fails → fix BEFORE proceeding.

---

## model/

- [ ] Zero React imports (no hooks, no JSX, no React types)
- [ ] Zero imports from `api/`, `store/`, `ui/` within same feature
- [ ] Types are `interface` (not `class`, not DDD entity)
- [ ] Transformers are pure functions (no side effects, no async)
- [ ] Validators return error objects — never throw
- [ ] Each function in its own directory with `index.ts`
- [ ] Spec file exists for every transformer/validator

---

## api/

- [ ] Uses TanStack Query for reads (`useQuery`)
- [ ] Uses TanStack Mutation for writes (`useMutation`)
- [ ] Hook naming: `use{Name}Query` or `use{Name}Mutation`
- [ ] Mapper in same directory transforms DTO → ViewModel (calls model/transformers)
- [ ] Zero business logic (just fetch + transform)
- [ ] No raw DTO exported — only mapped ViewModels leave the hook
- [ ] Each query hook in its own directory with `index.ts`
- [ ] Returns `QueryState<T>` or TanStack's native result type

---

## store/

- [ ] Only for LOCAL state (not server data — that's TanStack Query)
- [ ] Direct Zustand `create()` — NO port interface wrapping
- [ ] Store holds plain ViewModels (interfaces) — no class instances
- [ ] Hook naming: `use{Name}Store`
- [ ] UI state section if needed: `{ data: ..., ui: { selectedIds, step, ... } }`
- [ ] In its own directory with `index.ts`
- [ ] No imports from `ui/` layer

---

## ui/

- [ ] Components receive ViewModels via props or hooks — NEVER raw DTO
- [ ] Zero business logic in component body (all in hooks)
- [ ] Zero inline callbacks (`onClick={() => ...}` → handler from hook)
- [ ] Arrow functions, named exports, explicit return type `React.JSX.Element`
- [ ] No inline objects in JSX props (extract to const or hook)
- [ ] Every UI element checked against design system — used if exists
- [ ] Tailwind only — zero `style={{}}` (except dynamic computed widths)
- [ ] Colors from design tokens only — zero hardcoded hex
- [ ] Each component in its own directory with `index.ts`
- [ ] Hooks in `ui/hooks/{hookName}/` directory
- [ ] No `function` keyword — arrow functions everywhere

---

## Page (pages/)

- [ ] Composes features — zero business logic
- [ ] No hooks beyond feature-exported hooks
- [ ] No state management (that's feature's job)
- [ ] Imports features via `#features/{name}` index barrel
- [ ] Layout wrapper (if needed) from `#app/layouts/`

---

## index.ts (feature public API)

- [ ] Exports ONLY what pages need (components, hooks, types)
- [ ] Does NOT export store internals
- [ ] Does NOT export internal hooks not meant for pages
- [ ] Uses named exports (no default)

---

## Cross-Layer Boundary Check

Quick mental verify on every file:

```
LEGAL:                          ILLEGAL → STOP:
ui/ → model/                    model/ → ui/
ui/ → api/                      model/ → api/
ui/ → store/                    model/ → store/
api/ → model/                   store/ → ui/
pages/ → features/index.ts      feature-A/ → feature-B/
features/ → entities/           ui/ → another feature's internals
features/ → shared/             direct nivo/ag-grid import in feature
```

If illegal → move the import or extract to correct layer.

---

## Run After EVERY Layer

```bash
bash .kiro/scripts/fe-quality-gate.sh
```

This catches boundary violations, style issues, and convention breaks automatically.

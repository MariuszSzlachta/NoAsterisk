---
name: fe-testing
description: Frontend testing standards for the budget app. Layer-specific strategy, Vitest + Testing Library patterns, mock rules. Use for any frontend test creation or review.
---

# Frontend Testing Standards

Core rules from `steering/testing.md` apply. This skill adds FE-specific operational details.

## Tooling

| Tool | Role |
|---|---|
| Vitest | Test runner (globals: true, environment: jsdom) |
| @testing-library/react | Component rendering, user interaction |
| @testing-library/jest-dom | DOM matchers (toBeInTheDocument, toHaveClass) |
| vi.mock / vi.fn / vi.mocked | Mocking (Vitest native) |
| Playwright | E2E (separate from unit/integration) |

Config: `client/vitest.config.ts`. Setup: `client/src/test-setup.ts`.

## Layer Strategy

| Layer | What to test | Mocks | Pattern |
|---|---|---|---|
| **model/** (transformers, parsers, validators) | Pure unit tests | ZERO | Import function → assert output |
| **model/** (detectors, pipelines) | Unit tests | ZERO | Same — pure logic |
| **ui/hooks/** | Hook unit tests | Mock `api/` queries + `store/` | `vi.mock` the query hook → call hook → assert ViewModel |
| **store/** | Store unit tests | ZERO | Call actions → assert state |
| **ui/ components** | Component integration | Mock hooks | `render()` → assert DOM output |
| **adapters (shared/)** | Adapter unit tests | ZERO or minimal | `renderHook` → assert mapping |

### Priority Order

1. **model/** — highest ROI, pure functions, zero setup cost
2. **ui/hooks/** — business logic glue, catch transformer/query integration
3. **store/** — state machine correctness
4. **ui/ components** — render correctness (only when non-trivial logic in JSX)

## Test File Conventions

### File naming and placement

```
feature/model/parser/amount-parser.ts
feature/model/parser/amount-parser.spec.ts    ← next to source

feature/ui/hooks/useKpiWidget/useKpiWidget.ts
feature/ui/hooks/useKpiWidget/useKpiWidget.spec.ts  ← next to source

shared/adapters/grid/adapters/ag-grid/useAgGrid.ts
shared/adapters/grid/adapters/ag-grid/useAgGrid.spec.ts
```

Always `*.spec.ts` or `*.spec.tsx`. Never `*.test.*`.

### Imports — always explicit from vitest

```typescript
import { describe, expect, it, vi } from 'vitest';
```

Even though `globals: true` is set — explicit imports make dependencies clear and files self-contained.

## Pattern: model/ Tests (Pure Functions)

Zero mocks. Import → call → assert.

```typescript
import { describe, expect, it } from 'vitest';
import { mapDtoToViewModel } from './transformers';

describe('mapDtoToViewModel', () => {
  it('maps amount and currency to formatted string', () => {
    const dto = { amount: 8750, currency: 'PLN' };
    const vm = mapDtoToViewModel(dto);
    expect(vm.formattedAmount).toBe('8 750,00 zł');
  });

  it('handles zero amount', () => {
    const dto = { amount: 0, currency: 'PLN' };
    const vm = mapDtoToViewModel(dto);
    expect(vm.formattedAmount).toBe('0,00 zł');
  });
});
```

Use `it.each` for multiple cases of the same assertion:

```typescript
it.each([
  [29, 'var(--income)'],
  [15, 'var(--warning)'],
  [5, 'var(--expense)'],
] as const)('returns correct color for rate %d', (rate, expected) => {
  expect(getRateColor(rate)).toBe(expected);
});
```

## Pattern: ui/hooks/ Tests (Mocked Queries)

Mock the API query hook. Assert the ViewModel output.

```typescript
import { describe, expect, it, vi } from 'vitest';
import { useKpiQuery } from '#features/dashboard-widgets/api/useKpiQuery';
import { useKpiWidget } from '#features/dashboard-widgets/ui/hooks/useKpiWidget';

vi.mock('#features/dashboard-widgets/api/useKpiQuery', () => ({
  useKpiQuery: vi.fn(),
}));

const mockUseKpiQuery = vi.mocked(useKpiQuery);

describe('useKpiWidget', () => {
  it('returns loading state when query is loading', () => {
    mockUseKpiQuery.mockReturnValue({ data: [], isLoading: true });
    const result = useKpiWidget();
    expect(result).toEqual({ status: 'loading' });
  });

  it('returns loaded state with mapped VMs when query succeeds', () => {
    mockUseKpiQuery.mockReturnValue({
      data: [{ id: 'balance', label: 'Saldo', value: '100 zł' }],
      isLoading: false,
    });
    const result = useKpiWidget();
    expect(result.status).toBe('loaded');
  });
});
```

**Rules:**
- Mock at module level with `vi.mock()`
- Use `vi.mocked()` for type-safe mock access
- Test loading, success, and error states
- Assert ViewModel shape — NOT internal hook logic

## Pattern: store/ Tests (Zustand)

Import the store directly. Call actions. Assert state.

```typescript
import { beforeEach, describe, expect, it } from 'vitest';
import { useImportStore } from './useImportStore';

describe('useImportStore', () => {
  beforeEach(() => {
    useImportStore.setState({ rows: [], selectedIds: [] });
  });

  it('adds rows to state', () => {
    useImportStore.getState().addRows([{ id: '1', title: 'Test' }]);
    expect(useImportStore.getState().rows).toHaveLength(1);
  });

  it('toggles row selection', () => {
    useImportStore.getState().addRows([{ id: '1', title: 'Test' }]);
    useImportStore.getState().toggleSelection('1');
    expect(useImportStore.getState().selectedIds).toContain('1');
  });
});
```

**Rules:**
- Reset state in `beforeEach`
- Test via `.getState()` — no renderHook needed for Zustand
- ZERO mocks — store is pure state machine

## Pattern: ui/ Component Tests (Testing Library)

Only for components with non-trivial rendering logic (conditionals, maps, accessibility).

```typescript
import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { KpiCard } from './KpiCard';

describe('KpiCard', () => {
  it('renders label and value', () => {
    render(<KpiCard vm={{ label: 'Saldo', value: '100 zł', trend: 'up' }} />);
    expect(screen.getByText('Saldo')).toBeInTheDocument();
    expect(screen.getByText('100 zł')).toBeInTheDocument();
  });

  it('applies income color class for up trend', () => {
    render(<KpiCard vm={{ label: 'X', value: '1', trend: 'up' }} />);
    expect(screen.getByText('1')).toHaveClass('text-income');
  });
});
```

**Rules:**
- Query by role, text, or test-id — NEVER by CSS class for finding elements
- Mock hooks if component uses them (`vi.mock('#features/...')`)
- Don't test styles (Tailwind classes) unless they encode business logic (income/expense color)
- Don't test that React renders — test what the user sees

## Pattern: Adapter Tests (renderHook)

For shared adapters that expose hooks (e.g., AG Grid adapter):

```typescript
import { renderHook } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { useAgGrid } from './useAgGrid';

describe('useAgGrid', () => {
  it('maps port columns to AG Grid ColDef format', () => {
    const { result } = renderHook(() =>
      useAgGrid({ columns: testColumns, getRowId, sorting: undefined }),
    );
    expect(result.current.columnDefs).toHaveLength(2);
  });
});
```

## Test Data — Builders (Mandatory)

Never inline object literals. Use builder functions.

```typescript
// test-utils/builders.ts
const defaults: KpiDto = {
  id: 'balance',
  label: 'Saldo',
  value: '0 zł',
};

export const buildKpiDto = (overrides?: Partial<KpiDto>): KpiDto => ({
  ...defaults,
  ...overrides,
});
```

For large features, keep builders in a `__test-utils__/` directory within the feature or co-located with spec files.

## What NOT to Test

- Simple pass-through components (just rendering children/props)
- Type definitions, interfaces, enums
- That a component renders without crashing (if it has no logic)
- Framework behavior (React rendering, TanStack Query caching)
- Tailwind class presence (unless encoding business logic like income/expense)
- Simple getters on ViewModels with no logic

## Forbidden in Tests

| ❌ | Why |
|---|---|
| `any` / `as unknown` / `@ts-ignore` | Type safety matters in tests too |
| Inline object literals (no builder) | Unmaintainable, duplicated, hides intent |
| Mocking internal/private module internals | Couples test to implementation |
| `expect(true).toBe(true)` | Meaningless assertion |
| Testing implementation details (state variable names) | Test observable behavior |
| Snapshot tests for components | Brittle, low signal, hard to review |
| `vi.mock` for model/ layer functions | model/ is pure — test directly, no mocks |

## Naming Convention

Pattern: `does/should [action] when/if/for [condition]`

```typescript
it('returns loading state when query is pending', () => {});
it('maps amount to formatted PLN string', () => {});
it('groups categories beyond top 6 into "Inne" bucket', () => {});
it('handles empty input gracefully', () => {});
```

## Running Tests

```bash
cd client && npx vitest run                  # all tests, single run
cd client && npx vitest run src/features/X   # single feature
cd client && npx vitest                      # watch mode (dev)
```

## Coverage Expectations

| Layer | Expected coverage |
|---|---|
| model/ (transformers, parsers) | ~100% — pure functions, easy to test |
| ui/hooks/ | High — all states (loading, success, error) |
| store/ | High — all actions and state transitions |
| ui/ components | Selective — only non-trivial rendering logic |
| pages/ | None — composition only, tested via E2E |

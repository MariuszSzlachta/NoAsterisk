---
name: fe-layer-store
description: How to write the store/ layer in a frontend feature. Zustand patterns, when to use store vs TanStack Query. Use when creating or modifying store/ files in a feature.
---

# store/ Layer — Zustand for Local State

## When to Use Store

| Use Zustand store | Use TanStack Query |
|---|---|
| Multi-step wizard state (import pipeline) | Server data (lists, details, aggregates) |
| UI state (selections, filters, panel open) | Anything fetched from API |
| Client-only computed state machine | Cached server responses |
| Form state shared across components | Data that needs refetch/revalidation |

**Rule:** If data comes from the server → TanStack Query. If data lives only in browser → Zustand.

## Structure

```
store/
  useAnalyticsFiltersStore/
    useAnalyticsFiltersStore.ts
    index.ts
```

## Pattern — Direct Zustand Hook

```typescript
// useAnalyticsFiltersStore/useAnalyticsFiltersStore.ts
import { create } from 'zustand';
import type { Period, MetricType } from '#features/analytics/model/types';

interface AnalyticsFiltersState {
  readonly period: Period;
  readonly metrics: ReadonlyArray<MetricType>;
  readonly setPeriod: (period: Period) => void;
  readonly toggleMetric: (metric: MetricType) => void;
  readonly reset: () => void;
}

const DEFAULT_PERIOD: Period = '30d';
const DEFAULT_METRICS: ReadonlyArray<MetricType> = ['income', 'expense'];

export const useAnalyticsFiltersStore = create<AnalyticsFiltersState>((set) => ({
  period: DEFAULT_PERIOD,
  metrics: DEFAULT_METRICS,
  setPeriod: (period) => set({ period }),
  toggleMetric: (metric) =>
    set((state) => ({
      metrics: state.metrics.includes(metric)
        ? state.metrics.filter((m) => m !== metric)
        : [...state.metrics, metric],
    })),
  reset: () => set({ period: DEFAULT_PERIOD, metrics: DEFAULT_METRICS }),
}));
```

## Rules

1. **NO port/facade interface** — export the Zustand hook directly. It's internal to the feature.
2. **Store holds ViewModels** (plain objects/interfaces) — never class instances.
3. **Naming:** `use{Feature}{Concern}Store` — e.g. `useImportWizardStore`, `useAnalyticsFiltersStore`.
4. **Types from model/** — import interfaces from `../model/types`.
5. **UI state section** — if store has both data and UI state, separate clearly:

```typescript
interface ImportWizardState {
  // Data
  readonly rows: ReadonlyArray<TransactionViewModel>;
  // UI state
  readonly ui: {
    readonly step: ImportStep;
    readonly selectedIds: ReadonlySet<string>;
    readonly editingRowId: string | undefined;
  };
  // Actions
  readonly addRows: (rows: ReadonlyArray<TransactionViewModel>) => void;
  readonly setStep: (step: ImportStep) => void;
  readonly selectRows: (ids: ReadonlyArray<string>) => void;
}
```

## Immer — When State is Complex

For stores with nested updates, use immer middleware:

```typescript
import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';

export const useImportWizardStore = create<ImportWizardState>()(
  immer((set) => ({
    rows: [],
    ui: { step: 'upload', selectedIds: new Set(), editingRowId: undefined },
    updateRow: (id, updates) =>
      set((state) => {
        const idx = state.rows.findIndex((r) => r.id === id);
        if (idx !== -1) Object.assign(state.rows[idx], updates);
      }),
  }))
);
```

## What NOT to Do

| ❌ | ✅ |
|---|---|
| Port interface around store | Direct Zustand hook |
| Server data in store | TanStack Query |
| Class instances in state | Plain ViewModels (interfaces) |
| Store importing from ui/ | Store imports only from model/ |
| Global god-store | Per-feature store |
| `useStore.getState()` in components | Use hook: `const x = useStore((s) => s.x)` |

## Gate

After writing store/ → run:
1. `cd client && npx tsc --noEmit`
2. Check: no port wrapper? ViewModels only? No ui/ imports?

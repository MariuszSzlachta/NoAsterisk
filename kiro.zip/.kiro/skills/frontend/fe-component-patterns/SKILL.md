---
name: fe-component-patterns
description: React component and hook patterns for the budget app frontend. File organization, component structure, hook conventions, extraction rules. Use for any frontend component or hook work.
---

# Frontend Component Patterns

## Component Structure

```tsx
interface Props {
  title: string;
  onAction: (id: string) => void;
}

export const MyComponent = ({ title, onAction }: Props): React.JSX.Element => {
  const { handleClick, items } = useMyComponentLogic(onAction);

  return (
    <div>
      <h2>{title}</h2>
      {items.map(item => <ItemRow key={item.id} vm={item} />)}
    </div>
  );
};
```

## Rules

- Arrow functions everywhere. No `function` keyword.
- One public component per file. Named exports.
- Props interface in same file. Not `React.FC`.
- Explicit return type: `React.JSX.Element`.
- Zero logic in component body — delegate to hooks.
- Components receive ViewModels (plain objects) — never raw DTO.

## File Organization — Directory Per Unit

```
AnalyticsToolbar/
  AnalyticsToolbar.tsx
  index.ts               ← export { AnalyticsToolbar } from './AnalyticsToolbar';

useAnalyticsToolbar/
  useAnalyticsToolbar.ts
  useAnalyticsToolbar.spec.ts
  index.ts
```

**Exceptions (no directory needed):**
- `index.ts` barrel re-exports
- `types.ts` in `model/`
- Single-file configs (`constants.ts`)

## Sub-Components — Own Subdirectory

```
TopBar/
  TopBar.tsx
  TopBar.stories.tsx
  index.ts
  TopBarBreadcrumb/
    TopBarBreadcrumb.tsx
  SearchButton/
    SearchButton.tsx
    SearchButton.spec.tsx
```

- `index.ts` exports ONLY the public component
- Sub-components are internal (not re-exported)
- Consumers import: `import { TopBar } from '#app/layouts/TopBar'`

## Zero Inline Callbacks — All Logic in Hooks

```tsx
// ✅ ALL handlers come from hooks
export const TransactionRow = ({ vm }: TransactionRowProps): React.JSX.Element => {
  const { handleEdit, handleDelete } = useTransactionRowActions(vm.id);

  return (
    <tr>
      <td>{vm.title}</td>
      <td><Button onClick={handleEdit}>Edit</Button></td>
      <td><Button onClick={handleDelete}>Delete</Button></td>
    </tr>
  );
};

// ❌ Inline callback — even "simple" ones
<Button onClick={() => setOpen(true)}>Open</Button>

// ❌ Handler defined in component body
const handleEdit = (): void => { navigate(`/edit/${vm.id}`); };
```

## Hook Conventions

- One concern per hook. If needs "and" — split.
- Hooks return typed objects `{ handleX, data, isLoading }`, not tuples.
- Hooks live in `ui/hooks/` within the feature.
- Hook orchestrates: call api/store → transform via model/ → return ViewModel.

## Component Extraction Rule

Extract when:
- Block has 3+ nested elements with styling
- Block has its own logic (handlers, conditionals)
- Block is a visual "unit" (logo, toolbar, card section)
- You'd give it a name when explaining the layout

Inline is fine for:
- Simple wrapper div (`<div className="flex gap-2">`)
- Single element with no logic

## No Premature Memoization

Add `useCallback`/`useMemo` ONLY when:
- Measured performance problem (React DevTools profiler)
- Passing to `React.memo()` child that re-renders excessively
- Expensive computation (>1ms measured)

## Imports — Subpath Aliases

```typescript
// ✅ Aliased
import { useImportState } from '#features/csv-import';
import { formatMoney } from '#shared/lib';
import { KpiCard } from '#shared/ui/KpiCard';

// ❌ Relative
import { formatMoney } from '../../../shared/lib/formatMoney';
```

## Anti-Patterns

| ❌ | ✅ |
|---|---|
| `function` keyword | Arrow functions |
| Inline `onClick={() => ...}` | Handler from hook |
| Logic in component body | Dedicated hook |
| Helper function in `.tsx` file | `model/` or `shared/lib/` |
| Multiple components in one file | 1 file = 1 component |
| Loose file without directory | `Name/Name.tsx` + `index.ts` |
| `useCallback`/`useMemo` by default | Only when measured |
| `useEffect` for derived state | Compute in render/hook |
| Relative imports `../../..` | Subpath aliases `#shared/...` |
| Magic numbers in JSX | Named constants |
| Port/facade around Zustand | Direct store hook |
| DDD entities on FE | Plain interfaces + pure functions |

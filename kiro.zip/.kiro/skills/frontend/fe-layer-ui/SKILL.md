---
name: fe-layer-ui
description: How to write the ui/ layer in a frontend feature. Components, hooks, design system usage, styling rules. Use when creating or modifying ui/ files in a feature.
---

# ui/ Layer — Components + Hooks

## Structure

```
ui/
  hooks/
    useAnalyticsToolbar/
      useAnalyticsToolbar.ts
      index.ts
    useKpiWidget/
      useKpiWidget.ts
      index.ts
  AnalyticsToolbar/
    AnalyticsToolbar.tsx
    index.ts
  AnalyticsChart/
    AnalyticsChart.tsx
    index.ts
  KpiRow/
    KpiRow.tsx
    index.ts
```

## ui/hooks/ — Orchestration Hooks

Hooks combine api + store + model into ready-to-render data:

```typescript
// hooks/useKpiWidget/useKpiWidget.ts
import { useAnalyticsQuery } from '#features/analytics/api/useAnalyticsQuery';
import { useAnalyticsFiltersStore } from '#features/analytics/store/useAnalyticsFiltersStore';
import type { QueryState } from '#shared/api';
import type { KpiViewModel } from '#features/analytics/model/types';

interface KpiWidgetResult {
  readonly state: QueryState<ReadonlyArray<KpiViewModel>>;
  readonly period: string;
}

export const useKpiWidget = (): KpiWidgetResult => {
  const period = useAnalyticsFiltersStore((s) => s.period);
  const metrics = useAnalyticsFiltersStore((s) => s.metrics);
  const state = useAnalyticsQuery({ period, metrics });

  return { state, period };
};
```

## Components — Pure Rendering

```tsx
// AnalyticsKpiRow/AnalyticsKpiRow.tsx
import { KpiCard } from '#shared/ui';
import { QueryRenderer } from '#shared/ui/QueryRenderer';
import { useKpiWidget } from '#features/analytics/ui/hooks/useKpiWidget';
import type { KpiViewModel } from '#features/analytics/model/types';

export const AnalyticsKpiRow = (): React.JSX.Element => {
  const { state } = useKpiWidget();

  return (
    <QueryRenderer state={state} skeleton={<KpiRowSkeleton />}>
      {(kpis) => (
        <div className="grid grid-cols-4 gap-4">
          {kpis.map((kpi) => (
            <KpiCard key={kpi.label} label={kpi.label} value={kpi.value} delta={kpi.delta} trend={kpi.trend} />
          ))}
        </div>
      )}
    </QueryRenderer>
  );
};
```

## Design System — MANDATORY Check

Before writing ANY UI element:

1. Check `proj-design-system` skill — component exists?
2. YES → import and use. Done.
3. NO + generic → **STOP.** Create in `shared/ui/` first. Update design system skill. Then use.
4. NO + feature-specific → build in `ui/components/` within this feature.

| Writing this? | Use this instead |
|---|---|
| `<button className="...">` | `<Button variant="..." size="...">` |
| `<input className="...">` | `<Input label="..." error="...">` |
| `<div className="rounded-lg border bg-surface p-4">` | `<Card>` |
| Loading conditional | `<QueryRenderer state={} skeleton={}>` |
| Number with label | `<KpiCard label="" value="">` |
| Badge/tag | `<Badge variant="" color="">` |
| Hover text | `<Tooltip content="">` |

## Styling Rules (HARD)

- **Tailwind only.** Zero `style={{}}` except dynamic computed widths.
- **Design tokens only.** Colors: `bg-surface`, `text-foreground`, `border-border`. Never `bg-[#hex]`.
- **No `dark:` variants.** Tokens auto-switch via CSS variables.
- **Typography:** `font-sans` for text, `font-mono tabular-nums` for amounts.
- **Spacing:** Tailwind scale (`gap-4`, `p-6`, `rounded-md`). No `gap-[13px]`.

## Component Rules

- Arrow function, named export, explicit `React.JSX.Element` return type
- 1 file = 1 component
- Props interface in same file (not `React.FC`)
- Zero logic in body — everything comes from hooks
- Zero inline callbacks
- Directory per component with `index.ts`

## Handler Pattern

```tsx
// ❌ Logic in component
export const Toolbar = (): React.JSX.Element => {
  const [period, setPeriod] = useState<Period>('30d');
  const handlePeriodChange = (p: Period): void => { setPeriod(p); };
  return <select onChange={(e) => handlePeriodChange(e.target.value as Period)} />;
};

// ✅ Logic in hook, component just renders
export const Toolbar = (): React.JSX.Element => {
  const { period, handlePeriodChange, periodOptions } = useToolbar();
  return <PeriodSelector value={period} options={periodOptions} onChange={handlePeriodChange} />;
};
```

## Gate

After writing ui/ → run:
1. `cd client && npx tsc --noEmit`
2. `bash .kiro/scripts/fe-quality-gate.sh`
3. Screenshot with Playwright → verify visually
4. Check: design system used? No inline callbacks? No hardcoded colors?

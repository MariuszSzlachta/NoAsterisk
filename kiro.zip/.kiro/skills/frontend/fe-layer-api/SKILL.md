---
name: fe-layer-api
description: How to write the api/ layer in a frontend feature. TanStack Query hooks, DTO mapping, query keys. Use when creating or modifying api/ files in a feature.
---

# api/ Layer — TanStack Query + Mappers

## What Goes Here

- `use{Name}Query/` — read operations (TanStack `useQuery`)
- `use{Name}Mutation/` — write operations (TanStack `useMutation`)
- DTO → ViewModel mapping (inline in hook or separate `mappers.ts`)

## What Does NOT Go Here

- Business logic, validation, computed state
- Direct store access (that's ui/hooks/ orchestration)
- Raw API calls without TanStack Query wrapper
- React components or JSX

## Structure

```
api/
  constants.ts              ← API paths + query keys (MANDATORY)
  useAnalyticsQuery/
    useAnalyticsQuery.ts
    index.ts
  useCategoryBreakdownQuery/
    useCategoryBreakdownQuery.ts
    index.ts
  useImportMutation/
    useImportMutation.ts
    index.ts
```

## Constants — MANDATORY (Zero Magic Strings)

Every API path and query key MUST be a named constant. No string literals in hooks.

```typescript
// api/constants.ts
export const API_PATHS = {
  ANALYTICS: '/api/analytics',
  CATEGORY_BREAKDOWN: '/api/analytics/categories',
  CATEGORY_DRILLDOWN: '/api/analytics/categories/:id',
  IMPORTS: '/api/imports',
  TRANSACTIONS: '/api/transactions',
} as const;

export const QUERY_KEYS = {
  ANALYTICS: 'analytics',
  CATEGORY_BREAKDOWN: 'category-breakdown',
  CATEGORY_DRILLDOWN: 'category-drilldown',
  IMPORTS: 'imports',
  IMPORT_BATCHES: 'import-batches',
  TRANSACTIONS: 'transactions',
} as const;
```

Rules:
- One `constants.ts` per feature's `api/` layer
- `API_PATHS` — all endpoint URLs for this feature
- `QUERY_KEYS` — all TanStack Query key roots for this feature
- Used in both query hooks AND mutation invalidation
- If another feature needs to invalidate your query → export the key from feature's `index.ts`

## Query Hook Pattern

```typescript
// useAnalyticsQuery/useAnalyticsQuery.ts
import { useApiQuery } from '#shared/api';
import type { QueryState } from '#shared/api';
import { mapAnalyticsDtoToKpi } from '#features/analytics/model/transformers';
import type { KpiViewModel } from '#features/analytics/model/types';
import { API_PATHS, QUERY_KEYS } from '#features/analytics/api/constants';

interface AnalyticsQueryParams {
  readonly period: string;
  readonly metrics: ReadonlyArray<string>;
}

export const useAnalyticsQuery = (params: AnalyticsQueryParams): QueryState<KpiViewModel[]> => {
  return useApiQuery({
    queryKey: [QUERY_KEYS.ANALYTICS, params.period, params.metrics],
    path: API_PATHS.ANALYTICS,
    params: { period: params.period, metrics: params.metrics.join(',') },
    transform: (dto) => dto.items.map(mapAnalyticsDtoToKpi),
  });
};
```

## Mutation Hook Pattern

```typescript
// useImportMutation/useImportMutation.ts
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { httpClient } from '#shared/api';
import { API_PATHS, QUERY_KEYS } from '#features/csv-import/api/constants';

interface ImportPayload {
  readonly rows: ReadonlyArray<ImportRowDto>;
  readonly profileId: string;
}

interface ImportResult {
  readonly importedCount: number;
  readonly batchId: string;
}

export const useImportMutation = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload: ImportPayload): Promise<ImportResult> =>
      httpClient.post(API_PATHS.IMPORTS, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.TRANSACTIONS] });
      queryClient.invalidateQueries({ queryKey: [QUERY_KEYS.IMPORT_BATCHES] });
    },
  });
};
```

## Rules

1. **Zero magic strings** — paths in `API_PATHS`, keys in `QUERY_KEYS` from `constants.ts`. Never inline.
2. **Query keys** — structured arrays: `[QUERY_KEYS.X, id, params]`. Enables granular invalidation.
3. **Transform in query** — DTO→ViewModel mapping happens HERE, not in components.
4. **No raw DTO escapes** — hook returns `QueryState<ViewModel>`, never `QueryState<Dto>`.
5. **Naming** — `use{Entity}{Action}Query` / `use{Entity}{Action}Mutation`.
6. **Params as interface** — typed, readonly, never `Record<string, any>`.
7. **Invalidation in mutations** — always invalidate related queries on success, using `QUERY_KEYS`.

## QueryState Convention

This project uses a `QueryState<T>` discriminated union (from `#shared/api`):

```typescript
type QueryState<T> =
  | { status: 'notLoaded' }
  | { status: 'loading' }
  | { status: 'loaded'; data: T }
  | { status: 'error'; error: string };
```

Components consume this via `<QueryRenderer state={state} skeleton={...}>`.

## Gate

After writing api/ → run:
1. `cd client && npx tsc --noEmit`
2. Check: `constants.ts` exists with `API_PATHS` + `QUERY_KEYS`?
3. Check: zero string literals for paths/keys in hooks (all from constants)?
4. Check: hooks return typed state, not raw DTO? Transform uses model/transformers?

---
name: fe-layer-model
description: How to write the model/ layer in a frontend feature. Types, transformers, validators, pure functions. Use when creating or modifying model/ files in a feature.
---

# model/ Layer — Types + Pure Functions

## What Goes Here

- `types.ts` — interfaces (ViewModels, form values, enums)
- `transformers.ts` or `{name}/` directories — DTO → ViewModel mappers
- `validators.ts` or `{name}/` directories — input validation (pure, return errors)
- Pure helper functions (`computeHash`, `formatTitle`, `parseParam`)

## What Does NOT Go Here

- React hooks, JSX, React types
- Async functions (fetching = api/ layer)
- Store access (that's store/ layer)
- Side effects of any kind

## Structure

```
model/
  types.ts                          ← all interfaces for this feature
  transformers/
    transformers.ts
    transformers.spec.ts
    index.ts
  parseMetricsParam/
    parseMetricsParam.ts
    parseMetricsParam.spec.ts
    index.ts
  getTrendClass/
    getTrendClass.ts
    getTrendClass.spec.ts
    index.ts
```

## types.ts — Interfaces Only

```typescript
// ✅ Plain interfaces — this is the contract for the feature
export interface KpiViewModel {
  readonly label: string;
  readonly value: string;
  readonly delta: string;
  readonly trend: 'up' | 'down' | 'neutral';
}

export interface AnalyticsFilters {
  readonly period: Period;
  readonly metrics: ReadonlyArray<MetricType>;
}

export type Period = '7d' | '30d' | '90d' | '1y';
export type MetricType = 'income' | 'expense' | 'balance' | 'savings';
```

Rules:
- `interface` for object shapes, `type` for unions/literals
- `readonly` on all fields (ViewModels are immutable snapshots)
- No classes, no constructors, no methods
- No domain entities with behavior

## Transformers — Pure DTO→ViewModel Mappers

```typescript
// transformers/transformers.ts
import type { AnalyticsDto } from '#shared/api';
import type { KpiViewModel } from '#features/analytics/model/types';

export const mapAnalyticsDtoToKpi = (dto: AnalyticsDto): KpiViewModel => ({
  label: dto.metric_name,
  value: formatCurrency(dto.amount, dto.currency),
  delta: `${dto.change_percent > 0 ? '+' : ''}${dto.change_percent}%`,
  trend: dto.change_percent > 0 ? 'up' : dto.change_percent < 0 ? 'down' : 'neutral',
});
```

Rules:
- Pure function: same input → same output, no side effects
- Explicit return type
- One transformer per concern (don't bundle unrelated maps)
- MUST have `.spec.ts` — pure functions are trivially testable

## Validators — Return Errors, Never Throw

```typescript
// validateImportRow/validateImportRow.ts
import type { FieldErrors, ImportRowFormValues } from '#features/csv-import/model/types';

export const validateImportRow = (values: ImportRowFormValues): FieldErrors => {
  const errors: FieldErrors = {};

  if (!values.title.trim()) {
    errors.title = 'Title is required';
  }
  if (values.amount === 0) {
    errors.amount = 'Amount cannot be zero';
  }
  if (!values.date) {
    errors.date = 'Date is required';
  }

  return errors;
};
```

Rules:
- Returns `Record<string, string>` or typed `FieldErrors`
- Never throws — caller decides what to do with errors
- No async, no API calls, no store access

## Testing

Every function in model/ gets a spec:

```typescript
// getTrendClass/getTrendClass.spec.ts
import { getTrendClass } from './getTrendClass';

describe('getTrendClass', () => {
  it('returns "up" for positive change', () => {
    expect(getTrendClass(5.2)).toBe('text-income');
  });

  it('returns "down" for negative change', () => {
    expect(getTrendClass(-3.1)).toBe('text-expense');
  });

  it('returns "neutral" for zero', () => {
    expect(getTrendClass(0)).toBe('text-muted-foreground');
  });
});
```

## Gate

After writing model/ → run:
1. `cd client && npx tsc --noEmit`
2. `cd client && npx vitest run --testPathPattern=model`
3. Check: zero React imports? Zero async? All specs pass?

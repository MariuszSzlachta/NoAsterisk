---
name: fe-fix-review
description: How to handle code review feedback for frontend code. Systematic approach to fixing review findings by layer. Use when fixing review issues, handling reviewer feedback, or after "NEEDS_CHANGES" verdict.
---

# Fixing Review Feedback — Systematic Playbook

## Step 1: Read ALL Findings First

Read the full review file (`temp/{ticket}-review.md`). Do NOT start fixing immediately.
Categorize each finding by layer:

```
model/ findings:  [list]
api/ findings:    [list]
store/ findings:  [list]
ui/ findings:     [list]
cross-cut:        [list]
```

## Step 2: Fix Bottom-Up (model → api → store → ui)

Fix model/ issues FIRST — they often resolve downstream findings automatically.

### For Each Finding:

1. **Identify the layer** — open the corresponding fe-layer-{x} skill
2. **Understand the principle** — WHY is it wrong (not just what to change)
3. **Fix** — apply the correct pattern from the layer skill
4. **Self-check** — run fe-self-check for that layer
5. **Move to next finding**

## Step 3: Run Quality Gate

```bash
bash .kiro/scripts/fe-quality-gate.sh
```

If gate fails → fix. Do NOT submit for re-review with gate failures.

## Common Review Findings → Fix Patterns

### "Inline callback in JSX"
```tsx
// Finding: onClick={() => store.delete(id)}
// Fix: extract to hook
const { handleDelete } = useRowActions(id);
// ...
<Button onClick={handleDelete}>Delete</Button>
```
Open: `fe-layer-ui` → Handler Pattern section.

### "Raw DTO in component props"
```tsx
// Finding: component receives ApiResponse directly
// Fix: add transformer in model/, map in api/ or ui/hook
```
Open: `fe-layer-model` → Transformers section. Then `fe-layer-api` → Transform in query.

### "Business logic in component"
```tsx
// Finding: calculation/filtering in component body
// Fix: move to model/ (pure fn) or ui/hooks/ (orchestration)
```
If pure computation → `model/`. If needs store/api → `ui/hooks/`.

### "Hardcoded color / magic number"
```tsx
// Finding: bg-[#1a1f2e] or w-[347px]
// Fix: use design token or Tailwind scale
className="bg-surface"    // not bg-[#hex]
className="w-80"          // not w-[347px]
```

### "Missing design system component"
```tsx
// Finding: raw <button> or <input> instead of design system
// Fix: import from #shared/ui
import { Button } from '#shared/ui';
```
Open: `proj-design-system` skill → check what exists.

### "Port/facade around Zustand store"
```tsx
// Finding: unnecessary abstraction layer
// Fix: remove port interface, export Zustand hook directly
export const useFiltersStore = create<FiltersState>((set) => ({ ... }));
```
Open: `fe-layer-store` → Direct Zustand Hook pattern.

### "Function keyword"
```tsx
// Finding: export function MyComponent()
// Fix: arrow function
export const MyComponent = (): React.JSX.Element => { ... };
```

### "Feature cross-import"
```tsx
// Finding: features/A imports from features/B
// Fix: extract shared code to entities/ or shared/
```

### "Missing index.ts"
```
// Finding: directory without barrel export
// Fix: create index.ts
export { MyComponent } from './MyComponent';
```

## Step 4: Visual Verification (for ui/ fixes)

If any ui/ component was modified:
```bash
node scripts/playwright-screenshot.mjs /relevant-page --name fix-verification
```
Read screenshot. Confirm nothing broke visually.

## Step 5: Compile + Lint

```bash
cd client && npx tsc --noEmit
cd client && npx eslint --fix src/
```

## Rules

- **Zero complaining.** Findings are instructions. Execute them.
- **Zero skipping.** ALL severities fixed (including LOW).
- **Zero partial fixes.** Every finding gets a complete fix, not a band-aid.
- **If genuinely cannot fix** (external blocker) → add to `temp/decision-log.md` with reason.
- **Bottom-up order** prevents cascade (model fix often resolves api/ui findings).

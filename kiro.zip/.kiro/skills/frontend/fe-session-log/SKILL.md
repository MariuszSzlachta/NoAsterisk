---
name: fe-session-log
description: Log session metrics at end of FE development session. Captures duration, findings, skills used, review rounds. Use at session end, after "log session", "zakończ sesję", or when finishing FE work.
---

# Session Log — End-of-Session Telemetry

## When to Run

At the END of every FE development session — after all tasks are done. This is MANDATORY.

## What to Log

Append one JSON line to `temp/fe-session-log.jsonl`:

```jsonl
{"date":"2026-06-29","task":"short task description","duration_min":25,"layers_touched":["model","api","ui"],"skills_used":["fe-layer-model","fe-layer-ui","proj-design-system"],"skills_ignored":["fe-self-check"],"review_rounds":2,"review_findings":{"inline_callback":1,"hardcoded_color":0,"missing_design_system":0,"scope_creep":0,"raw_dto":0,"function_keyword":0,"other":1},"quality_gate_first_pass":true,"scope_creep":false,"notes":"clean session, self-check caught model issue before review"}
```

## Field Definitions

| Field | Type | Description |
|---|---|---|
| `date` | string | ISO date (YYYY-MM-DD) |
| `task` | string | Short description of what was built/fixed |
| `duration_min` | number | Approximate session duration in minutes |
| `layers_touched` | string[] | Which layers were worked on: `model`, `api`, `store`, `ui`, `page` |
| `skills_used` | string[] | Which FE skills were actively consulted/followed |
| `skills_ignored` | string[] | Which skills SHOULD have been used but weren't (be honest) |
| `review_rounds` | number | How many review→fix iterations (0 if no review) |
| `review_findings` | object | Count of findings by category |
| `quality_gate_first_pass` | boolean | Did `fe-quality-gate.sh` pass on first run? |
| `scope_creep` | boolean | Did agent make changes beyond what was asked? |
| `notes` | string | Free-form: what went well, what went wrong, root cause |

## Review Finding Categories

Track these standard categories in `review_findings`:

- `inline_callback` — handler defined inline in JSX
- `hardcoded_color` — hex color instead of design token
- `missing_design_system` — raw HTML instead of shared component
- `raw_dto` — DTO in component props instead of ViewModel
- `logic_in_component` — business logic in component body
- `scope_creep` — changes beyond requested scope
- `function_keyword` — used function instead of arrow
- `missing_index` — directory without barrel export
- `relative_import` — used `../` instead of `#` alias
- `port_facade` — unnecessary port/adapter on store
- `other` — anything not in above categories

## How to Produce the Log

At session end, reflect honestly:

1. What layers did I touch?
2. Which skills did I actually follow step-by-step?
3. Which skills exist but I skipped/forgot?
4. How many times did the reviewer send me back?
5. What types of findings came up?
6. Did I stay in scope?

## Execution

```bash
# Append to log file (create if doesn't exist)
echo '{"date":"...","task":"..."}' >> temp/fe-session-log.jsonl
```

## Rules

- **Be honest.** This is for improvement, not for looking good.
- **Log EVERY session.** Even short ones. Even clean ones (good data point).
- **skills_ignored is key.** If you skipped self-check and reviewer caught issues — that's the correlation we need.
- **notes field matters.** "Why" is more valuable than "what" for retrospective analysis.

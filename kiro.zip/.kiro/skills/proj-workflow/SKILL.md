---
name: proj-workflow
description: Task workflow orchestrator. Use when starting a new task, unsure about next step, or asking about the development process.
---

# Task Workflows

## Story (New Feature)

| Step | Action |
|---|---|
| **PLAN** | Read ticket. Explore affected code. Identify layers needed. Write plan. Do NOT code until confirmed. |
| **IMPLEMENT** | Build bottom-up: domain → application → infrastructure → presentation → frontend. Tests alongside. |
| **VERIFY** | Run quality gates: `npx tsc --noEmit && npx eslint --fix src/ && npx jest` |
| **REVIEW** | Switch to code-review agent. Review all changed files. |
| **SHIP** | Commit, push, create PR — only when developer explicitly asks. |

## Bug Fix

| Step | Action |
|---|---|
| **DIAGNOSE** | Find root cause. Define fix scope. If significant refactoring needed → suggest pivot to Story. |
| **FIX** | Write failing test FIRST. Fix code. Confirm test passes. |
| **VERIFY → SHIP** | Same as Story. |

## Rules

- No code without understanding — diagnosis/planning comes first.
- The developer controls the pace — agent suggests, developer decides.
- If unclear about scope — ask before implementing.

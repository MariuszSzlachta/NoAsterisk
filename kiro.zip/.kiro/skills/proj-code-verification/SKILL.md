---
name: proj-code-verification
description: Code quality verification and quality gates. Use when asked to verify code quality, fix compilation errors, or run checks.
---

# Code Verification

## Steps (execute in order)

### 1. TypeScript Compilation
```bash
npx tsc --noEmit
```
Fix each error individually. Never guess types — search for definitions first.

### 2. Linting
```bash
npx eslint --fix src/
```

### 3. Formatting
```bash
npx prettier --write src/
```

### 4. Tests
```bash
npx jest --passWithNoTests
```

### 5. Architecture Check
- Domain entities have behavior (not anemic)?
- Mappers at every layer boundary?
- No entity types in API responses?
- Zod validation on all external inputs?
- No raw data reaching AI adapters?
- ABAC ownership checks present?
- Tests exist for all logic files?

## Rules

- Don't guess types. Search for the exact definition first.
- No `@ts-ignore`, no `any`, no `as` casts as fixes.
- Process errors one at a time, not in batch.
- If unsure about correct type — search source code before attempting fix.

---
name: proj-code-review-followup
description: Follow-up code review session — verify fixes from previous review, assess fix quality, review new code. Use when dev says "I fixed the issues", "check my fixes", "next round", "follow-up review", "verify my changes", or when a previous review file exists in temp/.
---

# Follow-Up Review Session

## When to use

Previous review exists (`temp/{ticket}-review.md`). Dev has made changes. This is NOT a fresh review — it's verification + incremental review.

## Flow

1. **Load previous review** — ask dev for file or check `temp/*-review.md`.

2. **Verify fixes FIRST** (before looking at anything new):
   - For each previous CRITICAL/HIGH: is it addressed?
   - **Quality of fix assessment:**
     - ✅ Fixed properly — root cause solved, pattern correct
     - ⚠️ Partially fixed — symptom addressed but root cause remains
     - ❌ Not addressed — still present
     - 🔄 Fixed but introduced new issue — regression
   - **Systemic fixes:** applied everywhere or only in one file? Check ALL affected files listed in previous review.
   - **Did dev understand WHY?** — if fix is mechanical (moved file but logic unchanged), flag it. Understanding matters more than compliance.

3. **Review new code** (files not in previous review):
   - Same layer-by-layer approach, same 5 questions per file.
   - Check: does new code follow patterns established in fixes? Or repeats old mistakes?

4. **Update review file:**
   - Mark resolved items with status (✅/⚠️/❌/🔄).
   - Add new findings.
   - Update verdict.
   - Note session number (CR-2, CR-3...).

5. **Escalation** (if CRITICAL items remain after 2+ sessions):
   - "This is session {N}. These CRITICAL items are still unresolved: {list}."
   - "This blocks merge. Let's discuss — is the architecture unclear, or is the fix approach wrong?"
   - Offer: pair session to work through the fix together.

## What NOT to do in follow-up

- Don't re-review files that haven't changed since last session.
- Don't lower severity because "dev tried hard" — the violation is the violation.
- Don't accept a fix that moves the problem to another file — trace it.
- Don't skip systemic verification — if previous review said "fix in all 5 files", check all 5.

---
name: proj-design-system
description: Design system component catalog for the budget app. Defines available UI primitives, their APIs, and rules for reuse vs creation. Use when building any UI — pages, features, layouts — to ensure existing components are reused and new ones are added to the design system properly.
---

# Design System — Use It, Extend It, Never Bypass It

## Golden Rule

**NEVER write raw HTML/Tailwind for something the design system already provides.**
If a component is missing — add it to `client/src/shared/ui/` first, then use it.

## Available Components

All live in `client/src/shared/ui/` and are exported from `client/src/shared/ui/index.ts`.

### Button
```tsx
import { Button } from '#shared/ui';

<Button variant="primary" size="md" icon={<Icon />}>Label</Button>
<Button variant="ghost" size="icon" icon={<X />} />
```
| Prop | Type | Default |
|------|------|---------|
| variant | `'primary' \| 'secondary' \| 'ghost' \| 'destructive'` | `'primary'` |
| size | `'sm' \| 'md' \| 'lg' \| 'icon'` | `'md'` |
| icon | `ReactNode` | — |
| children | `ReactNode` | — |
| + all native button attributes | | |

### Card / CardHeader
```tsx
import { Card, CardHeader } from '#shared/ui';

<Card>
  <CardHeader title="Monthly Budget" subtitle="June 2025" action={<Button>Edit</Button>} />
  {children}
</Card>
```
| Component | Props |
|-----------|-------|
| Card | `children`, `className?` |
| CardHeader | `title: string`, `subtitle?: string`, `action?: ReactNode` |

### Badge
```tsx
import { Badge } from '#shared/ui';

<Badge variant="soft" color="income" dot>Active</Badge>
```
| Prop | Type | Default |
|------|------|---------|
| variant | `'soft' \| 'solid' \| 'outline'` | — |
| color | `'primary' \| 'income' \| 'expense' \| 'warning' \| 'neutral' \| 'purple' \| 'blue' \| 'amber'` | — |
| dot | `boolean` | `false` |
| children | `ReactNode` | — |

### Input
```tsx
import { Input } from '#shared/ui';

<Input label="Amount" error="Required" icon={<Search />} placeholder="0.00" />
```
| Prop | Type |
|------|------|
| label | `string?` |
| error | `string?` |
| icon | `ReactNode?` |
| + all native input attributes | |

### Progress
```tsx
import { Progress } from '#shared/ui';

<Progress value={750} max={1000} color="income" />
```
| Prop | Type | Default |
|------|------|---------|
| value | `number` | — |
| max | `number` | `100` |
| color | `'primary' \| 'income' \| 'expense' \| 'warning'` | `'primary'` |

### Skeleton
```tsx
import { Skeleton } from '#shared/ui';

<Skeleton className="h-4 w-32" />
```
Loading placeholder. Style via `className`.

### SelectionToolbar
```tsx
import { SelectionToolbar } from '#shared/ui';

<SelectionToolbar
  count={selected.length}
  actions={[{ label: 'Delete', icon: <Trash />, onClick: handleDelete }]}
  onClear={clearSelection}
/>
```

### DropdownMenu
```tsx
import { DropdownMenu } from '#shared/ui';

<DropdownMenu
  trigger={<Button variant="ghost" size="icon" icon={<MoreVertical />} />}
  align="right"
  items={[
    { type: 'item', label: 'Edit', icon: <Edit />, onClick: handleEdit },
    { type: 'separator' },
    { type: 'item', label: 'Delete', icon: <Trash />, onClick: handleDelete, variant: 'destructive' },
  ]}
/>
```

### BudgetProgressList
```tsx
import { BudgetProgressList } from '#shared/ui';

<BudgetProgressList
  items={[{ label: 'Groceries', spent: 450, limit: 600, color: 'var(--cat-groceries)' }]}
  currency="PLN"
/>
```

### KpiCard
```tsx
import { KpiCard } from '#shared/ui';

<KpiCard label="Saldo" value="12 450,00 zł" icon={<Wallet size={16} />} delta="+2,4%" trend="up" tooltip="Suma wszystkich środków na kontach." iconHref="/reports/balance" />
```
| Prop | Type | Default |
|------|------|---------|
| label | `string` | — |
| value | `string` | — |
| icon | `ReactNode` | — |
| delta | `string?` | — |
| trend | `'up' \| 'down' \| 'neutral'` | `'neutral'` |
| tooltip | `string?` | — |
| iconHref | `string?` | — |

When `iconHref` is provided, the icon renders as a clickable `<Link>` to the target route with accessible aria-label.

### Tooltip
```tsx
import { Tooltip } from '#shared/ui';

<Tooltip content="Explanation text visible on hover/focus." placement="bottom">
  <Info size={14} />
</Tooltip>
```
| Prop | Type | Default |
|------|------|---------|
| content | `string` | — |
| children | `ReactNode` | — |
| placement | `'top' \| 'bottom' \| 'left' \| 'right'` | `'top'` |
| noFlip | `boolean` | `false` |
| flipThreshold | `number` | `60` |
| clampTo | `string` (CSS selector) | `'main'` |
| edgeGap | `number` | `8` |

Lightweight infotip (string-only). For rich content use a Popover (not yet built). Accessible: keyboard-focusable, `aria-describedby` linked, visible on hover and focus. Auto-flips placement when near viewport edge. Clamps horizontally to nearest scrollable container (`main` by default).

### QueryRenderer
```tsx
import { QueryRenderer } from '#shared/ui/QueryRenderer';

<QueryRenderer state={state} skeleton={<Skeleton className="h-24 w-full" />}>
  {(data) => <MyWidget items={data} />}
</QueryRenderer>
```
| Prop | Type | Default |
|------|------|---------|
| state | `QueryState<TData>` | — |
| skeleton | `React.JSX.Element?` | `<Skeleton className="h-[320px] w-full" />` |
| children | `(data: TData) => React.JSX.Element` | — |

Generic render-prop component that handles the `QueryState<T>` discriminated union. Renders skeleton for `loading`/`notLoaded`, error message for `error`, and calls `children(data)` for `loaded`.

**Rule: Use QueryRenderer for ANY component that consumes QueryState. Never write manual status switch inline.**

## Rules for Using Components

1. **Search before building.** Before writing any UI element, check if it exists above.
2. **Compose, don't duplicate.** Build complex UI by composing these primitives.
3. **Use design tokens.** Colors via `text-primary`, `bg-surface`, etc. — never hardcoded hex.
4. **Props over custom classes.** Use component props (variant, size, color) before reaching for `className`.

## IMPORTANT: Update This Skill After Adding Components

When you add a new component to `shared/ui/`:
1. **Update this SKILL.md** — add the component to the "Available Components" section above with full props API and usage example.
2. This ensures future agent sessions know about the new component and reuse it.

If you skip this step, the next session will recreate the component from scratch. Don't skip it.

## When to Add a New Component

Add to the design system when:
- The pattern appears (or will appear) in 2+ places
- It's a generic UI primitive (not feature-specific business logic)
- It has clear, reusable props API

### How to Add

1. Create folder: `client/src/shared/ui/ComponentName/`
2. Files needed:
   - `ComponentName.tsx` — component implementation
   - `ComponentName.stories.tsx` — Storybook story
   - `index.ts` — re-export (if needed for sub-components)
3. Export from `client/src/shared/ui/index.ts`
4. Follow existing patterns (see Button.tsx as reference):
   - Props interface at top
   - Variant/size maps as `Record<Enum, string>`
   - Tailwind classes only, design tokens only
   - Explicit return type `React.JSX.Element`

### Component Conventions

- Arrow functions, named export
- Props interface (not `type`), in same file
- Variants via `Record<VariantType, string>` class maps
- Sizes via `Record<SizeType, string>` class maps
- `className` prop for escape hatch (appended, not replacing)
- No `forwardRef` unless the component genuinely needs external ref access
- Storybook story MUST cover all variants

## What Does NOT Go in shared/ui

- Feature-specific composite components → `features/{name}/ui/components/`
- Layout components (AppShell, Sidebar) → `app/layouts/`
- Components with business logic or domain awareness → feature layer
- Components that call hooks (other than DOM/ref hooks) → feature layer

## Missing Components (Known Gaps — Add When Needed)

- Modal / Dialog
- Toast / Notification
- Tabs
- Table (basic, non-AG-Grid)
- Avatar
- Toggle / Switch
- Select (custom dropdown)
- Checkbox
- Radio

When implementing a feature that needs one of these — build it in `shared/ui/` first, then use it.

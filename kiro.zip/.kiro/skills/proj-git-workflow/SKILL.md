---
name: proj-git-workflow
description: Git workflow for the budget app. Covers branch naming, commit format, MR creation. Use for any git operation or MR task.
---

# Git Workflow

## Branch Naming

```
feature/BUD-XXX-short-description
fix/BUD-XXX-short-description
hotfix/BUD-XXX-short-description
```

## Commit Format

```
[BUD-XXX] Descriptive message
```

First commit: `[BUD-XXX] Task title`

## Starting Work

```bash
git fetch origin main
git checkout -b feature/BUD-XXX-description origin/main
```

## Updating Branch

```bash
git fetch origin main
git merge origin/main
git push
```

Always merge. Never rebase.

## Creating MR

```bash
glab mr create \
  --source-branch feature/BUD-XXX-description \
  --target-branch main \
  --title "[BUD-XXX] Task title" \
  --squash-before-merge \
  --remove-source-branch
```

## Rules

- Squash commits on merge to main.
- No force push without explicit user confirmation.
- No history-changing operations without confirmation.
- Keep PRs focused — one feature/fix per branch.

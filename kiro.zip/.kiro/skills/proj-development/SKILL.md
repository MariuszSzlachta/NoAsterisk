---
name: proj-development
description: Development standards for the NestJS + React budget app. Covers module structure, implementation flow, and quality gates. Use for any feature implementation or code generation.
---

# Development Standards

## Session Start — Context Loading

Before writing any code, read:
1. `.kiro/development-plan.md` — understand current phase, bullet tasks, and scope boundaries.
2. `temp/decision-log.md` (if exists) — know what's deferred, why, and whether any deferred item's "revisit when" matches the current phase (if so — raise it).

## Steering Files

Architecture, coding rules, and patterns are defined in steering files:
- `clean-architecture-be.md` — BE layers, mappers, CQRS, ports
- `clean-architecture-fe.md` — FE Feature-Sliced Design, flat layers
- `clean-code.md` — SOLID, naming, DI with Symbol tokens
- `cq-typescript.md` — strict TS, Zod, Value Objects (BE)
- `cq-react.md` — React conventions, styling, hooks
- `security.md` — anonymization, ABAC, AI adapter contracts
- `testing.md` — layer-specific test strategy
- `anti-patterns-learned-be.md` — BE mistakes to never repeat
- `anti-patterns-learned-fe.md` — FE mistakes to never repeat

## Module Structure (Backend)

```
src/modules/{feature}/
  domain/
    entities/           ← Business logic
    value-objects/      ← Money, DateRange, etc.
    ports/              ← Interfaces (CategorizationPort, etc.)
  application/
    commands/           ← Write operations (handler + command)
    queries/            ← Read operations (handler + query)
    mappers/            ← Domain ↔ Response DTO
  infrastructure/
    repositories/       ← PostgreSQL implementations
    adapters/           ← AI adapter implementations
    mappers/            ← Persistence ↔ Domain Entity
  presentation/
    controllers/        ← Thin — validate + delegate
    dto/                ← Zod schemas
```

## Implementation Order

1. Domain → `npx tsc --noEmit`
2. Application → verify
3. Infrastructure → verify
4. Presentation → verify
5. Frontend → verify
6. Tests alongside each layer

## Quality Gates

```bash
npx tsc --noEmit
bash .kiro/scripts/arch-lint.sh
npx eslint --fix src/
npx prettier --write src/
npx jest --passWithNoTests
```

## Self-Check Protocol

Each layer must pass its self-check BEFORE proceeding to the next. Full checklists are in `prompts/backend-developer.md`. Key gates:

- **Domain:** Constructor validates invariants, zero forbidden imports, entity has behaviour
- **Application:** No imports from presentation/infra, DTOs use own types (not domain enums), workspace scoping on every port method
- **Infrastructure:** Returns domain entities (not raw rows), all queries workspace-scoped
- **Presentation:** Controller is thin (validate→delegate→respond), Zod uses own `z.enum()`, all inputs bounded

Run `bash .kiro/scripts/arch-lint.sh` after all layers — catches illegal import directions automatically.

See `steering/anti-patterns-learned-be.md` and `steering/anti-patterns-learned-fe.md` for project-specific mistakes to avoid.

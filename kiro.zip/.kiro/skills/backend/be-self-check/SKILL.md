---
name: proj-self-check
description: Per-layer self-check checklists for the backend-developer agent. Execute the relevant section after writing each layer. Use when implementing features, after writing domain/application/infrastructure/presentation code.
---

# Self-Check — Execute After Each Layer

Read the section matching the layer you just wrote. Every item must pass. If any fails → fix before proceeding.

---

## Domain

- [ ] Constructor validates ALL invariants — no path creates invalid instance
- [ ] `create()` generates new ID + timestamps; constructor = reconstitution (takes ID)
- [ ] Zero imports from application/, infrastructure/, presentation/
- [ ] Entity has behaviour (methods with guards + logic, not just getters)
- [ ] Every method returning new instance propagates ALL fields (check field-by-field)
- [ ] `DomainError` thrown on violations (not generic `Error`)
- [ ] Type guards for domain concepts defined HERE (not in infrastructure)
- [ ] Value Objects for repeated concept pairs (amount+currency → Money)

---

## Application

- [ ] Handler imports ONLY from `domain/` and `@shared/` — never presentation, never infrastructure
- [ ] Response DTO uses own string literals — never imports domain enums
- [ ] Mapper translates domain enum → string via `Record<Enum, string>` (exhaustive)
- [ ] Every port method signature includes `workspaceId`
- [ ] Handler asserts `entity.workspaceId === command.workspaceId` on every external ID
- [ ] Handler orchestrates the FULL use case — no business logic leaks to controller
- [ ] No `as` casts, no `any`

---

## Infrastructure

- [ ] Repository returns Domain Entity (via mapper), never raw DB row/record
- [ ] Every query filters by `workspaceId` — zero global queries
- [ ] Type guards imported from domain, not redefined here
- [ ] Mapper handles null/undefined from DB gracefully
- [ ] No business logic in repository (no if/else on domain rules)
- [ ] No duplicate providers — if another module needs this repo, export it from owning module

---

## Presentation

- [ ] Controller method: validate (Zod) → ONE handler call → map response. Nothing else.
- [ ] Zod uses `z.enum([...])` — never `z.nativeEnum(DomainType)`
- [ ] Every `:id` path param: `z.string().uuid()`
- [ ] Every string input: `.max(N)`
- [ ] Every array input: `.max(N)`
- [ ] Shared utils (pipes, guards) from `@shared/` — no cross-module imports
- [ ] No `@Res()` pattern — use exception filters
- [ ] Error messages: no user input echoed, no internal state exposed

---

## Import Direction Gate

Quick mental check on every file:

```
LEGAL:                              ILLEGAL → STOP:
presentation → application           application → presentation
presentation → @shared               domain → anything
application → domain                 presentation → domain
application → @shared                presentation → infrastructure
infrastructure → domain             infrastructure → application
infrastructure → @shared            module-A → module-B internals
```

If illegal → move the type to correct layer or `@shared/`.

---

## Security Boundary

For every NEW port method:
1. Has `workspaceId` param? → if no, add it
2. Can params come from user input? → handler must validate ownership first

For every handler with external IDs:
1. Fetch entity → assert `workspaceId` match → then proceed

For every endpoint:
- Body size fits within parser limit?
- Strings bounded? Arrays bounded?
- Errors don't leak data?

---

## Entity Completeness (use when writing/modifying entities)

Entity is NOT done until:
1. Constructor validates ALL invariants
2. All fields `readonly`
3. State transitions = explicit methods with guards
4. `create()` = new ID + timestamps. Constructor = reconstitution.
5. ALL copy methods propagate ALL fields (verify each one)
6. `DomainError` on violations

---

## Cross-Cut Review (after last layer)

Run: `bash .kiro/scripts/arch-lint.sh`

Then mentally verify:
- No DTO imports domain types?
- All repos workspace-scoped?
- Controller thin? (no `if` beyond HTTP status mapping)
- Works with second workspace without changes?
- Zero `as` / `any`?

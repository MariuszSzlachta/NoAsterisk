---
name: proj-testing
description: Testing standards for the budget app. Layer-specific strategy, builders, mocking rules. Use for any test creation or review.
---

# Testing Standards

Core rules defined in `steering/testing.md`. This skill adds operational details.

## Layer Strategy

| Layer | Type | Mocks | Tools |
|---|---|---|---|
| Domain | Pure unit tests | ZERO | Jest |
| Application | Unit tests | Mock port interfaces | Jest + jest.spyOn |
| Infrastructure | Integration tests | Real DB | Jest + test containers |
| Presentation | Contract tests | Mock handlers | Supertest |
| Frontend | Component + integration | Mock API | Jest + Testing Library |

## Test Data — Builders (mandatory)

```typescript
export const buildTransaction = (overrides?: Partial<TransactionProps>): Transaction =>
  new Transaction({ ...defaults, ...overrides });
```

Never inline object literals.

## File Placement

- Unit: `*.spec.ts` next to source
- Integration: `__tests__/` within module
- E2E: `test/` at project root

## Forbidden

- `any`, `as unknown`, `@ts-ignore` in tests
- Mocking internal/private methods
- Inline object literals instead of builders
- `expect(true).toBe(true)`

# Claude Design Prompt — Budget App

## About the App

A SaaS web application for personal and family budget management. Users import bank statements (CSV), the system automatically categorizes transactions (rules engine + AI fallback), and a dashboard shows budget status, sub-budgets, and spending trends.

**Target audience:** individuals managing personal/family budgets, couples sharing finances, freelancers separating business from personal expenses.

**UI tone & character:** Conservative, clean, readable — this is a finance app. Zero gamification, zero flashy colors. Priority: fast data scanning, number readability, clear information hierarchy.

**Visual inspirations (ranked):**
1. https://dribbble.com/shots/25163824-Bank-Dashboard — **(9.5/10, primary inspiration)** Excellent layout, KPI cards, chart proportions, sidebar. This is closest to what I want.
2. https://dribbble.com/shots/22952490-Valmax-Bank-Dashboard-UI-UX — **(8/10)** Modern, great typography and spacing, interesting chart cards.
3. https://dribbble.com/shots/19327131-Introducing-IO — **(7/10)** Conservative, clean, good information hierarchy. Lacks "life" but solid foundation.

**Direction:** Combine density and layout from #1 (Bank Dashboard), modern typography from #2 (Valmax), conservatism and readability from #3 (IO). Result should be professional but not boring — a finance app that looks like a 2026 product, not a legacy banking portal.

---

## Tech Stack (design constraints)

| Layer | Tool | Design implication |
|-------|------|-------------------|
| UI Components | **shadcn/ui + Radix** | Base components (Button, Input, Dialog, Select, Tabs, Sheet, DropdownMenu, Toast). Design MUST use existing shadcn/ui variants — don't design from scratch. |
| CSS | **Tailwind CSS v4** | Utility-first. Design tokens defined as CSS variables in `:root` / `.dark`. |
| Grid/Tables | **AG Grid Community** | Ready-made DataGrid with virtualization, sorting, filtering, editable cells. Design styles it via CSS variables (`--ag-*`), don't design a custom table from scratch. |
| Charts | **Nivo** (React) | Chart library (Line, Bar, Pie, Heatmap). Design defines color palette and layout, Nivo renders. |
| Icons | **Lucide React** | 1000+ icons (outline style, consistent stroke width). |
| Dark mode | **From day 0** | Every screen MUST have light and dark version. Tailwind `dark:` variant, class strategy. |
| Routing | **React Router v7** | URL-based navigation, nested layouts. |

**Important:** Don't design custom components where shadcn/ui has ready-made ones (e.g., custom dropdown, custom modal). Design *compositions* of these components and their color variants.

---

## Design Tokens to Define

I need a complete token system:

### Colors (CSS variables)
- `--background`, `--foreground` (main surfaces)
- `--card`, `--card-foreground`
- `--primary`, `--primary-foreground` (CTA, main actions)
- `--secondary`, `--secondary-foreground` (secondary actions)
- `--muted`, `--muted-foreground` (disabled, subtle)
- `--accent`, `--accent-foreground` (hover, highlights)
- `--destructive`, `--destructive-foreground` (delete, error)
- `--border`, `--input`, `--ring` (outlines, focus)
- `--success`, `--warning` (status indicators)
- **Semantic financial colors:** income (green), expense (red/coral), neutral/transfer (gray/blue)
- **Chart palette:** 6-8 colors for spending categories (distinguishable in both themes)

### Typography
- Font family (sans-serif, readable for numbers — consider tabular nums)
- Scale: xs, sm, base, lg, xl, 2xl, 3xl
- Weights: regular (400), medium (500), semibold (600), bold (700)
- Numbers in tables: monospace/tabular figures (column alignment)

### Spacing & Layout
- Sidebar width (collapsed/expanded)
- Content max-width
- Card padding
- Grid gaps
- Section spacing

### Border radius
- Global `--radius` (shadcn/ui pattern): sm, md, lg

---

## Screens to Design

### 1. Layout Shell (global)
- **Sidebar** (left): main navigation (icons + labels), logo/app name at top, user avatar + workspace name at bottom
- **Topbar** (optional): breadcrumbs, global actions (dark mode toggle, notifications)
- **Main content area**: max-width container, responsive
- Sidebar collapsible (icon-only mode on smaller screens)

### 2. Dashboard (main view after login)
- KPI cards: total balance, expenses this month, income this month, savings
- Chart: spending vs income trend (line chart, last 6 months)
- Chart: spending per category (donut/pie or horizontal bar)
- List: recent transactions (5-10, with category and amount)
- Budgets: sub-budget progress bars (spent vs limit)

### 3. Import Wizard (multi-step flow)
**Step 1 — Upload:**
- Drag & drop zone (CSV file)
- Or "Choose file" button
- Info text: "Data is parsed locally, nothing is sent to the server"

**Step 2 — Preview & Column Mapping:**
- Preview of first 5 CSV rows (mini read-only table)
- Dropdown per column: mapping to system fields (date, amount, title, counterparty)
- Auto-detected profile badge (if recognized bank)
- "Next" / "Back" buttons

**Step 3 — Review & Edit (DataGrid):**
- AG Grid with anonymized data
- Editable cells (title, category)
- Color-coded category tags
- Toolbar: batch actions (select multiple → change category)
- Side panel: "Smart edit" — suggested batch changes for similar transactions
- Status bar: "245 transactions, 12 uncategorized, 3 potential PII"

**Step 4 — Confirm & Import:**
- Summary: total transactions, new, duplicates (skipped)
- Progress bar (chunked upload)
- Success state: link to browse imported transactions

### 4. Transactions List
- AG Grid: date, title (anonymized), amount, category (tag), batch name
- Filters: date range, category, amount min/max, status
- Column sorting
- Bulk actions: re-categorize, delete

### 5. Categorization Rules
- Table: keyword, matcher type (contains/exact), target category, priority
- Actions: inline edit, delete, re-order (drag?)
- "Add rule" button → modal/sheet with form
- Section "System rules" (read-only, lower priority) vs "My rules"

### 6. Budget Overview
- Sub-budget list: name, limit, spent, remaining, progress bar
- Click → detail: transactions in this sub-budget, monthly trend chart
- Create/edit sub-budget (sheet/modal)

### 7. Import Profiles (settings)
- Profile list (per bank): name, bank, last import date
- Edit: column mapping, anonymization rules, parser config
- "Auto-detect" test (upload CSV → system shows which profile matches)

### 8. Auth (Login / Register)
- Minimalist, centered form
- Logo + app name
- Email + password fields
- "Sign up" / "Sign in" link toggle
- Optional: social login buttons placeholder (future feature, reserve space)

---

## Component States to Include

- **Empty states:** no transactions, no rules, first import (onboarding guidance)
- **Loading:** skeleton loaders (not spinners — shadcn/ui Skeleton component)
- **Error:** inline error messages (forms), toast notifications (actions), error pages (500, 404)
- **Success:** confirmation toast, green status indicator
- **Conflict (409):** banner "Data has been modified by another user — refresh to see changes"

---

## Visual Style Guidelines

- **Conservative and professional** — this is a finance app, not social media
- **Generous whitespace** (light) / dark surfaces (dark) — data needs to breathe
- **Number readability is priority** — tabular figures, right-aligned amounts, clear thousand separators
- **Color palette:** neutral base (gray scale) + 1 primary accent (blue? teal? indigo? — your choice, keep it professional). Income = green, expense = muted red/coral (not aggressive).
- **Minimal decoration** — zero gradients, zero box-shadows on everything, subtle borders only
- **Hierarchy through typography** — size + weight, not colors or icons
- **Dense but not cramped** — lots of data on screen (finance), but with breathing room

---

## Deliverables

1. **Design tokens** — complete light + dark palette (CSS variables, ready to paste into Tailwind config)
2. **Layout shell** — sidebar + content structure
3. **All 8 screens** — in both themes (light + dark)
4. **Component variants** — buttons, badges/tags (categories), status indicators, cards
5. **AG Grid theme** — how the DataGrid looks in this design system (header colors, row styles, editable cells, selection highlight)
6. **Chart color palette** — 8 colors per theme (distinguishable, accessible contrast)
7. **Typography specimen** — headings, body, numbers, labels
8. **Empty states & loading** — patterns for empty views

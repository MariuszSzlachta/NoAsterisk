#!/bin/bash
# Architecture boundary linter — catches illegal imports between layers and modules.
# Run: bash .kiro/scripts/arch-lint.sh

set -euo pipefail

ERRORS=0
WARNINGS=0

# Detect modules directory (project uses server/src/{module}/ flat structure)
if [ -d "server/src/modules" ]; then
  MODULES_DIR="server/src/modules"
elif [ -d "src/modules" ]; then
  MODULES_DIR="src/modules"
elif [ -d "server/src" ]; then
  # Flat structure: server/src/transactions/, server/src/categories/, etc.
  MODULES_DIR="server/src"
elif [ -d "src" ]; then
  MODULES_DIR="src"
else
  echo "⚠️  No source directory found"
  exit 0
fi

echo "🔍 Checking architecture boundaries in $MODULES_DIR..."

# 1. Domain must not import from application, infrastructure, or presentation
echo ""
echo "── Domain layer (must import nothing outside domain/shared) ──"
while IFS= read -r file; do
  if grep -qE "from '.*(application|infrastructure|presentation)/" "$file" 2>/dev/null; then
    echo "❌ $file imports from forbidden layer"
    grep -nE "from '.*(application|infrastructure|presentation)/" "$file"
    ERRORS=$((ERRORS + 1))
  fi
done < <(find "$MODULES_DIR"/*/domain -name '*.ts' 2>/dev/null)

# 2. Presentation must not import from domain (directly) — except @shared/domain
echo ""
echo "── Presentation layer (must not import from domain) ──"
while IFS= read -r file; do
  if grep -qE "from '.*(/domain/|@[a-z]+/domain)" "$file" 2>/dev/null; then
    # Exclude @shared/domain (that's allowed — shared domain errors, etc.)
    real_violations=$(grep -nE "from '.*(/domain/|@[a-z]+/domain)" "$file" | grep -v "@shared/domain" || true)
    if [ -n "$real_violations" ]; then
      echo "❌ $file imports from domain layer"
      echo "$real_violations"
      ERRORS=$((ERRORS + 1))
    fi
  fi
done < <(find "$MODULES_DIR"/*/presentation -name '*.ts' 2>/dev/null)

# 3. Application must not import from presentation or infrastructure
echo ""
echo "── Application layer (must not import from presentation/infrastructure) ──"
while IFS= read -r file; do
  if grep -qE "from '.*(presentation|infrastructure)/" "$file" 2>/dev/null; then
    echo "❌ $file imports from forbidden layer"
    grep -nE "from '.*(presentation|infrastructure)/" "$file"
    ERRORS=$((ERRORS + 1))
  fi
done < <(find "$MODULES_DIR"/*/application -name '*.ts' 2>/dev/null)

# 4. Cross-module imports (module A importing from module B internals, not @shared)
# NOTE: Module.ts importing another Module class for DI wiring is architecturally acceptable
#       but importing internal layers (domain/, application/ports, etc.) is a coupling smell.
#       This check flags ALL cross-module imports — use judgment on .module.ts vs internal imports.
echo ""
echo "── Cross-module imports (forbidden — only @shared allowed between modules) ──"

# Get list of project module names (path aliases)
PROJECT_MODULES=""
for module_dir in "$MODULES_DIR"/*/; do
  [ -d "$module_dir" ] || continue
  name=$(basename "$module_dir")
  [ "$name" = "shared" ] && continue
  PROJECT_MODULES="$PROJECT_MODULES $name"
done

for module_dir in "$MODULES_DIR"/*/; do
  [ -d "$module_dir" ] || continue
  module_name=$(basename "$module_dir")

  while IFS= read -r file; do
    for other_module in $PROJECT_MODULES; do
      [ "$other_module" = "$module_name" ] && continue
      # Check if file imports from another project module's internals
      if grep -qE "from '@${other_module}/" "$file" 2>/dev/null; then
        violations=$(grep -nE "from '@${other_module}/" "$file" || true)
        if [ -n "$violations" ]; then
          echo "❌ $file imports from @${other_module}/:"
          echo "$violations"
          ERRORS=$((ERRORS + 1))
        fi
      fi
    done
  done < <(find "$module_dir" -name '*.ts' 2>/dev/null)
done

# 5. Zod schemas must not use nativeEnum with domain imports
echo ""
echo "── Zod schemas (must not use z.nativeEnum with domain types) ──"
while IFS= read -r file; do
  if grep -qE "z\.nativeEnum" "$file" 2>/dev/null; then
    if grep -qE "from '.*domain/" "$file" 2>/dev/null; then
      echo "❌ $file uses z.nativeEnum with domain import"
      grep -n "z.nativeEnum" "$file"
      ERRORS=$((ERRORS + 1))
    fi
  fi
done < <(find "$MODULES_DIR"/*/presentation -name '*.ts' 2>/dev/null)

# 6. Repository ports — workspace scope signal check
echo ""
echo "── Repository ports (workspace scope signal) ──"
while IFS= read -r file; do
  # Skip files with ARCH-EXCEPTION: global-scope comment
  if grep -qE "ARCH-EXCEPTION:.*global.scope" "$file" 2>/dev/null; then
    continue
  fi
  if ! grep -qE "workspaceId" "$file" 2>/dev/null; then
    echo "⚠️  $file — no workspaceId found. Verify: is global scope intentional? (AP-5/AP-12)"
    WARNINGS=$((WARNINGS + 1))
  fi
done < <(find "$MODULES_DIR"/*/domain/ports -name '*repository*' -o -name '*repo*' 2>/dev/null)

# 7. Domain entities — spec file existence
echo ""
echo "── Domain entities (spec files required) ──"
while IFS= read -r file; do
  spec="${file%.ts}.spec.ts"
  if [ ! -f "$spec" ]; then
    echo "❌ Missing spec: $file"
    ERRORS=$((ERRORS + 1))
  fi
done < <(find "$MODULES_DIR"/*/domain -maxdepth 1 -name '*entity*.ts' ! -name '*.spec.ts' ! -name 'index.ts' 2>/dev/null; find "$MODULES_DIR"/*/domain/entities -name '*.ts' ! -name '*.spec.ts' ! -name 'index.ts' 2>/dev/null)

# Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
  echo "✅ Architecture boundaries OK — no violations found"
  exit 0
elif [ $ERRORS -eq 0 ]; then
  echo "⚠️  No errors but $WARNINGS warning(s). Review workspace scope decisions."
  exit 0
else
  echo "❌ Found $ERRORS architecture violation(s). Fix before proceeding."
  exit 1
fi

# Development Plan

## Faza 1: Import Batch (backend foundations) — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| 1 | Import Batch entity + in-memory repository | ✅ Done |
| 2 | Import transactions command (batch import handler) | ✅ Done |
| 3 | PII validation service | ✅ Done |
| 4 | Import endpoint z feedback loop | ✅ Done |
| 5 | Batch management endpoints | ✅ Done |

### Zaimplementowane (Faza 1)

- `ImportBatch` entity — statusy: Pending → InProgress → Complete/PartiallyRejected, `completedAt`, invariant guards, `markPartiallyRejected()` z state guard
- `ImportBatchRepository` port + in-memory adapter
- `ImportTransactionsHandler` — deklaratywny flow, sekwencyjne przetwarzanie, batch-level dedup (`BatchAlreadyImportedError`), per-row dedup (contentHash), workspace ownership validation, PII validation zintegrowana
- `Transaction` entity rozszerzony o `contentHash` + `importBatchId` (propagowane we wszystkich metodach)
- `TransactionRepository` port rozszerzony o `existsByContentHash(workspaceId, hash)` + `deleteByBatchId(workspaceId, batchId)`
- PII Validation Service: plugin architecture (PII_RULES DI token), 5 reguł (IBAN mod97, Card Luhn, PESEL checksum, Email, Phone), Unicode zero-width sanitization
- `POST /imports` endpoint: Zod DTO (SHA-256, max 200 rows, filename sanitization), 201/207/409
- `ImportsModule` importuje `TransactionsModule` (shared repo instance)
- Global `DomainExceptionFilter`, CORS, body parser 1mb
- Path alias `@imports/*` + Jest moduleNameMapper
- Batch management: `GET /imports` (paginated), `GET /imports/:id`, `DELETE /imports/:id` (cascade delete transactions)
- `GetImportBatchesHandler`, `GetImportBatchByIdHandler` queries + `DeleteImportBatchHandler` command
- `ImportBatchResponseDto` + `ImportBatchResponseMapper` (string literal status, no domain enum leak)
- `Transaction` entity rozszerzony o `workspaceId` — invariant guard, propagacja we wszystkich metodach (S1 security fix)
- `InMemoryTransactionRepository` — `existsByContentHash` i `deleteByBatchId` filtrują po `workspaceId` (defense-in-depth)
- `TransactionMapper` + `TransactionRecord` — full round-trip z `contentHash`, `importBatchId`, `workspaceId`
- Handlers return `undefined`/`false` for not-found → Controller throws NestJS `NotFoundException` (404)
- `findPaged(workspaceId, PageOptions)` w `ImportBatchRepository` port + implementacja

### Testy (Faza 1)

- 18 unit testów ImportBatch entity
- 9 unit testów ImportTransactionsHandler
- 3 unit testy DeleteImportBatchHandler
- 5 unit testów GetImportBatches/GetImportBatchById handlers
- 40 unit testów PII rules (it.each)
- 5 unit testów PiiValidationService orchestrator
- 15 integration testów ImportsController (supertest)
- 1 istniejący test app.controller
- **Total: 98/98 PASS, tsc --noEmit clean**

---

## Faza 2: Categorization Rules (silnik reguł) — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| 6 | Rule entity + repository | ✅ Done |
| 7 | Rule CRUD (commands + queries + controller) | ✅ Done |
| 8 | Matcher strategy (ContainsMatcher, ExactMatcher) | ✅ Done |
| 9 | Auto-categorize command | ✅ Done |
| 10 | Kategoryzacja przy imporcie (hook) | ✅ Done |

### Zaimplementowane (Faza 2)

- `CategorizationRule` entity — invariant guards, `update()` immutable, priorytet-based ordering
- `CategorizationRuleRepository` port + in-memory adapter (workspace-scoped)
- `MatcherType` enum (`Contains`, `Exact`) + matcher strategy: `ContainsMatcher`, `ExactMatcher`
- CRUD: `CreateRuleHandler`, `UpdateRuleHandler`, `DeleteRuleHandler`, `GetRulesHandler`
- `AutoCategorizeHandler` — applies rules by priority, scoped by workspace + batchId
- Import hook: `ImportTransactionsHandler` wywołuje auto-categorize po zapisie batcha
- `CategorizationRulesController` — full CRUD + `POST /categorization-rules/auto-categorize`
- Zod DTO: `CreateRuleSchema`, `UpdateRuleSchema` (string literals, no domain enum leak)
- `CategorizationRuleResponseMapper` + DTO (AP-1/AP-2 compliant)
- `CategorizationRulesModule` exports repo token, importuje `TransactionsModule`
- Path alias `@categorization-rules/*` + Jest moduleNameMapper

### Testy (Faza 2)

- Entity spec, matchers spec, auto-categorize handler spec
- Rule handlers spec (CRUD)
- Controller integration spec (supertest)
- **Total project: 152/152 PASS, tsc --noEmit clean**

---

## Faza 2.5: Auth + ABAC (users, JWT, permissions) — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| A1 | User entity + repository (roles: Superuser/Member, password hash) | ✅ Done |
| A2 | Auth module — register + login + JWT (access 15m, refresh 7d) | ✅ Done |
| A3 | Guards + decorators (JwtAuthGuard, RolesGuard, @CurrentUser) | ✅ Done |
| A4 | Permission entity + repository (ABAC workspace-level) | ✅ Done |
| A5 | Wire guards into existing controllers (replace TEMP_WORKSPACE_ID) | ✅ Done |

### Zaimplementowane (Faza 2.5)

- `User` entity (email, passwordHash, role, workspaceId) + `UserRole` enum (Superuser/Member)
- `Workspace` entity w osobnym module `src/workspaces/` (bounded context)
- `Permission` entity (userId, resourceType, resourceId, actions[]) — ABAC
- `RegisterHandler` — creates workspace → user → permission (full workspace access)
- `LoginHandler` — validates credentials, returns JWT pair
- `RefreshHandler` — token rotation (new access + new refresh)
- `TokenPort` + `JwtTokenAdapter` (@nestjs/jwt), `PasswordHasherPort` + `BcryptPasswordHasher`
- `JwtAuthGuard` global (APP_GUARD) with `@Public()` bypass
- `RolesGuard` global (APP_GUARD) with typed `@Roles(UserRole)` decorator
- `@CurrentUser()` decorator — extracts userId/workspaceId/role from JWT
- Rate limiting: `@nestjs/throttler` (5/min auth, 10/min refresh, 30/min global)
- All controllers migrated from `TEMP_WORKSPACE_ID` to `@CurrentUser()`
- `AuthModule` exports guards/repos, imports `WorkspacesModule`

### Testy (Faza 2.5)

- 9 unit testów User entity
- 6 unit testów Workspace entity
- 9 unit testów Permission entity
- 7 unit testów RegisterHandler
- 4 unit testów LoginHandler
- 3 unit testów RefreshHandler
- 7 unit testów Guards (JwtAuth + Roles + @Public)
- 8 integration testów AuthController (register/login/refresh + validation)
- **Total project: 204/204 PASS, tsc --noEmit clean**

---

## Faza 3: Import Profiles (backend) — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| 11 | ImportProfile entity + value objects (ColumnMapping, ParserConfig, AnonymizationConfig) | ✅ Done |
| 12 | Repository port + in-memory adapter (workspace-scoped) | ✅ Done |
| 13 | Create + Update command handlers | ✅ Done |
| 14 | Get + Delete handlers + controller + Zod DTOs | ✅ Done |
| 15 | Profile auto-detect (match profile by CSV headers) | ✅ Done |
| 16 | Integracja z import flow (opcjonalny profileId w imporcie) | ✅ Done |

### Zaimplementowane (Faza 3)

- `ImportProfile` entity — invariant guards (id, workspaceId, name max 255, columnMappings non-empty + unique sourceColumn), immutable `update()`, `matchesHeaders(headers)` behavior
- Value Objects: `ColumnMapping` (sourceColumn, targetField, isRequired), `ParserConfig` (delimiter, hasHeader, dateFormat, encoding), `AnonymizationConfig` (fieldsToAnonymize, strategy + Set-based equals)
- `AnonymizationStrategy` enum (Hash, Mask, Remove)
- `ImportProfileRepository` port + `InMemoryImportProfileRepository` (workspace-scoped: findById, findByWorkspaceId, findByName, delete)
- `CreateImportProfileHandler` — name uniqueness per workspace, constructs VOs from plain command data
- `UpdateImportProfileHandler` — workspace-scoped, name uniqueness on change, immutable update
- `DeleteImportProfileHandler` — workspace-scoped, returns boolean
- `GetImportProfilesHandler`, `GetImportProfileByIdHandler` — workspace-scoped queries
- `DetectImportProfileHandler` — first-match semantics via entity.matchesHeaders()
- `ImportProfileResponseMapper` + DTO (string literals, explicit STRATEGY_TO_DTO record)
- Shared `STRATEGY_FROM_DTO` mapper in `application/mappers/strategy.mapper.ts`
- `ImportProfilesController` — thin (validate→delegate→respond), zero domain imports
- Zod DTOs: `.strict()` on all schemas, `z.enum(['Hash','Mask','Remove'])` (AP-2), `delimiter.max(10)`
- `ImportProfilesModule` — exports IMPORT_PROFILE_REPOSITORY
- Integration: optional `profileId` in `ImportTransactionsCommand` + Zod DTO, validated workspace-scoped
- `ImportsModule` imports `ImportProfilesModule`
- Path alias `@import-profiles/*` + Jest moduleNameMapper
- All handlers use `DomainError` (not BadRequestException) — framework leak fixed

### Testy (Faza 3)

- 29 unit testów ImportProfile entity + VOs (invariants, update, matchesHeaders, equals)
- 5 unit testów Create/Update handlers (happy path, duplicate name, not found)
- 3 unit testy DetectImportProfileHandler (match, no match, first match)
- 3 unit testy Delete handler (happy, not found, wrong workspace)
- 4 unit testy Get/GetById handlers
- 1 unit test ImportTransactionsHandler (profile not found)
- Istniejące testy import handler nadal PASS (profileRepo mock dodany)
- **Total project: 248/248 PASS, tsc --noEmit clean**

---

## Faza 4.0: Frontend Setup — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| 14 | React + Vite setup (strict TS, Zustand, papaparse, FSD structure, proxy) | ✅ Done |

---

## Faza 4.1: App Shell (Layout) — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| 4.1.1 | Sidebar — logo, nawigacja (items + active state), user section na dole | ✅ Done |
| 4.1.2 | TopBar — breadcrumb, search input, notification bell, theme toggle, CTA "Importuj CSV" | ✅ Done |
| 4.1.3 | AppShell layout — composycja Sidebar + TopBar + Outlet content slot, podpięcie do routera | ✅ Done |

### Zaimplementowane (Faza 4.1)

- i18n setup: react-i18next + i18next, PL namespace, all strings via `t()`
- Atomic composition: TopBar (SearchButton, NotificationBell, ThemeToggle, ImportCsvLink, MobileMenuButton), Sidebar (SidebarNavLink, SectionLabel, UserSection)
- Design system reuse: shared/ui/Button (NotificationBell, ThemeToggle, MobileMenuButton), shared/ui/Badge (nav badge)
- Responsive: sidebar lg breakpoint (1024px), mobile overlay with backdrop, hamburger menu
- Route meta in app/routing/route-meta.ts (i18n keys)
- AppShell with Outlet, Navigate redirect / → /dashboard
- Placeholder pages: TransactionsPage, BudgetsPage (arrow functions)
- All pages converted to arrow functions, HomePage deleted
- tsc clean, 74 tests pass

---

## Faza 4.1.5: Agent & Quality Improvements (between shell and widgets)

| # | Zadanie | Status |
|---|---|---|
| 4.1.5.1 | Split feature-developer agent → backend-developer + frontend-developer | ✅ Done |
| 4.1.5.2 | Design system skill (proj-design-system) — component catalog for agent reuse | ✅ Done |
| 4.1.5.3 | Security review frontend (anonymization flow, raw data handling, token storage) | ✅ Done |
| 4.1.5.4 | Flat Storybook structure (flatten hierarchy, improve discoverability) | ✅ Done |
| 4.1.5.5 | Plate developer agents (evaluate & configure agentic tooling) | ⬜ |

---

## Faza 4.2: Dashboard Widgets — ✅ COMPLETE

| # | Zadanie | Status |
|---|---|---|
| 4.2.1 | KpiCard — single card (label, value, icon, delta badge) + Storybook story | ✅ Done |
| 4.2.2 | KPI row — grid 4 kolumny z mock danymi na DashboardPage | ✅ Done |
| 4.2.3 | Trend chart widget — "Przychody vs wydatki" line chart (Nivo fasada) + Storybook | ✅ Done |
| 4.2.4 | Category donut widget — "Wydatki wg kategorii" pie chart z legendą + Storybook | ✅ Done |
| 4.2.5 | Recent transactions widget — lista (ikona, merchant, category·date, kwota) + Storybook | ✅ Done |
| 4.2.6 | Dashboard page composition — złożenie widgetów w grid layout (KPI → charts → budgets+recent) | ✅ Done |

---

## Faza 4.2.7: Dashboard Enhancements (interakcja + nawigacja)

| # | Zadanie | Status |
|---|---|---|
| 4.2.7.1 | Infotipy na KPI — tooltip z wyjaśnieniem metryki na każdym KpiCard | ✅ Done |
| 4.2.7.2 | Klikalne ikony KPI — po kliknięciu otwiera raport szczegółowy (saldo, przychody, wydatki, oszczędności) | ✅ Done |
| 4.2.7.3 | KPI raporty → single /analytics page z filtrami (DEC-058) | ✅ Done |
| 4.2.7.4 | Buttony nawigacyjne na widgetach — linki do Transakcji, Budżetów, Analizy na odpowiednich widgetach | ✅ Done |
| 4.2.7.5 | Analytics: breakdown kategorii (donut + lista) pod KPI, widoczny przy metric=expenses/income | ✅ Done |

**4.2.7.5 — Fixy do zrobienia po review:**
1. ~~**"Inne" tail bucket**~~ — N/A (horizontal bars, nie donut — wszystkie kategorie widoczne)
2. **Area chart zamiast line** — trend per kategoria: przy małej wariancji (np. 1.9k–2.3k) area chart jest czytelniejszy niż gołą linią
3. ~~**Kolorowa kropka kategorii przy transakcjach**~~ — ✅ Done (4.2.8.1)
4. **Delta kolor** — upewnić się że spadek wydatków = zielony (dobrze), wzrost = czerwony (źle). Odwrotna logika niż dla przychodów.
| 4.2.7.6 | Analytics: filter state sync to URL (shareableURLs), bar/area chart renderers | ⬜ |

---

## Faza 4.2.8: Dashboard Polish & New Widgets

| # | Zadanie | Status |
|---|---|---|
| 4.2.8.1 | Kolorowe kategorie w "Ostatnie transakcje" — kolorowa kropka kategorii przy każdej transakcji (spójność z donutem i budżetami) | ✅ Done |
| 4.2.8.2 | Kafelek obok donuta — "Savings Rate" (circular progress, % przychodów zaoszczędzonych w miesiącu, np. 29%) | ✅ Done |
| 4.2.8.3 | Widget "Stałe wydatki" — lista recurring expenses (subskrypcje, stałe opłaty) z sumą miesięczną | ✅ Done |
| 4.2.8.4 | Widget "Budget Health" — gauge/radial indicator, overall % wykorzystania budżetów (zielony/żółty/czerwony) | ❌ Abandoned (DEC-060) |
| 4.2.8.5 | Widget "Spending Velocity" — mini chart: tempo wydatków vs dzień miesiąca, prognoza czy zmieścisz się w planie | ⬜ |
| 4.2.8.6 | Widget "Uncategorized" alert badge — liczba transakcji bez kategorii, CTA do kategoryzacji | ⬜ |
| 4.2.8.7 | Widget "Month-over-month" — jedna liczba: % zmiana wydatków vs poprzedni miesiąc z arrow up/down | ⬜ |

### Specyfikacja dla FE-deva

**4.2.8.1 — Kolorowe kategorie w transakcjach**
- W `RecentTransactions` widget dodać kolorową kropkę (8px circle) po lewej stronie ikony lub zamiast szarej ikony
- Kolor = kolor kategorii z donuta (spójna paleta)
- Kwoty ujemne: nasycony czerwony (`text-destructive`), przychody: nasycony zielony (`text-success`)
- Opcjonalnie: subtle background na ikonce w kolorze kategorii (opacity 10%)

**4.2.8.2 — Savings Rate kafelek**
- Umieścić obok donuta (prawa kolumna, pod donutem lub jako osobny kafelek w tym samym wierszu)
- Circular progress (Nivo radial bar lub custom SVG ring)
- Formuła: `oszczędności / przychody * 100` (tu: 2450/8500 ≈ 29%)
- Kolor: zielony > 20%, żółty 10-20%, czerwony < 10%
- Label: "Stopa oszczędności" + wartość % + kwota absolutna pod spodem

**4.2.8.3 — Stałe wydatki (Recurring)**
- **Definicja recurring (MVP):** ręczne oznaczanie — flaga `isRecurring: boolean` + `recurrenceCycle: 'monthly' | 'yearly'` na Transaction entity. User taguje transakcję jako stałą.
- **Auto-detekcja (post-MVP):** ten sam merchant + podobna kwota (±10%) ≥ 3 miesiące z rzędu → auto-flag jako recurring.
- **Przeliczenie:** ✅ wydatki roczne przeliczane na miesięczne (240 zł/rok → 20 zł/mies.) w "Razem/mies."
- **Co wyświetlamy:** top 5 posortowane po kwocie miesięcznej desc + link "Wszystkie →"
- ✅ Każda pozycja: nazwa + kwota + cykl (mies./rok.)
- ✅ Summary row na dole: "Razem: X zł/mies."
- **Layout:** fixed height widgetu (max 5 pozycji), wewnętrzny scroll w tabelce, summary row sticky. Dashboard NIE scrolluje — widget mieści się w viewport.
- **Lokalizacja:** Row 3 obok "Ostatnie transakcje" (50/50) — NIE dodajemy nowego wiersza pod budżetami.

**Status 4.2.8.3:** ✅ DONE
- ✅ Widget komponent + hook + mock data + testy (formatAmount, toMonthlyAmount)
- ✅ Sortowanie top 5 po kwocie miesięcznej desc
- ✅ Link "Wszystkie →" (action prop)
- ✅ Lokalizacja w row 3 grid (grid-rows: 1.5fr_1.5fr_1.3fr)
- ⬜ Dashboard no-scroll (wymaga kompromisu — 4 widgetowe rowsy nie mieszczą się w 1080px viewport; rozwiązanie: zmniejszyć wysokość chart row LUB połączyć Budżety z czymś)

**4.2.8.4 — Budget Health gauge**
- Jeden radial/gauge chart: overall % = suma wydatków / suma limitów budżetów
- Kolory: < 70% zielony, 70-90% żółty, > 90% czerwony
- Tekst w środku: "72%" + "w normie" / "uwaga" / "przekroczono"
- Mały kafelek (1 kolumna), obok savings rate lub w nowym wierszu

**4.2.8.5 — Spending Velocity**
- Miniaturowy area chart: oś X = dni miesiąca (1-30), oś Y = kumulatywne wydatki
- Linia prosta = idealny (liniowy) rozkład budżetu
- Linia krzywa = rzeczywiste tempo
- Tekst: "Dzień 28/30 — wydano 95% budżetu"
- Jeśli ahead of pace → żółty/czerwony, behind → zielony

**4.2.8.6 — Uncategorized alert**
- Mały badge/chip na dashboardzie (albo w headerze budżetów)
- Tekst: "12 transakcji bez kategorii"
- Klik → nawigacja do `/transactions?filter=uncategorized`
- Kolor: żółty (warning)

**4.2.8.7 — Month-over-month trend**
- KpiCard-style kafelek (może piąty w górnym rzędzie albo wydzielony)
- Jedna liczba: "+5.3%" lub "-2.1%"
- Arrow up (czerwony = więcej wydatków) / arrow down (zielony = mniej wydatków)
- Subtitle: "vs poprzedni miesiąc"

### Layout grid (finalne rozmieszczenie — NO SCROLL)

```
Row 1: [KPI x4]
Row 2: [Trend chart (2/3)] [Donut + Savings Rate kafelek (1/3)]
Row 3: [Budżety (1/2)] [Stałe wydatki (1/2)]  ← recurring obok budżetów
Row 4: [Ostatnie transakcje (1/2)] [Budget Health + Spending Velocity (1/2)]
```

**Zasada:** Dashboard mieści się w viewport bez scroll. Widgety z listami (Stałe wydatki, Ostatnie transakcje) mają fixed height + wewnętrzny scroll. Summary row sticky.

### Priorytet implementacji

1. **4.2.8.1** (kolorowe kategorie) — quick win, poprawia balans kolorów prawa strona
2. **4.2.8.2** (savings rate) — wypełnia lukę obok donuta
3. **4.2.8.7** (month-over-month) — prosty kafelek, duża wartość informacyjna
4. **4.2.8.6** (uncategorized alert) — małe, ale motywuje do akcji
5. **4.2.8.4** (budget health) — nowy widget, wymaga gauge component
6. **4.2.8.3** (recurring) — wymaga logiki detekcji recurring
7. **4.2.8.5** (spending velocity) — najbardziej złożony chart

### Zmiana chartu: Donut → Horizontal Bar (Analytics breakdown) — ✅ DONE

**Problem:** Donut + legenda zajmują ~40% karty, reszta to puste miejsce. Donut nie skaluje się na szerokie karty.

**Rozwiązanie:** Zamienić donut na **horizontal bar chart** w sekcji "Wydatki wg kategorii" na stronie Analiza.

**Specyfikacja:**
- Każda kategoria = kolorowy pasek (sorted desc by kwota)
- Label po lewej: nazwa kategorii
- Wartość po prawej: kwota + procent
- Pasek kolorowy proporcjonalny do max kategorii (nie 100% — największa = full width, reszta proporcjonalnie)
- Total na górze karty: "7 150 zł / mies." (przeniesiony z środka donuta)
- Klik na pasek → rozwija drill-down (trend + transakcje, jak jest teraz)
- Kolory pasków = ta sama paleta co donut (spójność z dashboardem)
- Na dashboardzie (mały widget) donut ZOSTAJE — tam jest kompaktowy i działa. Zmiana dotyczy TYLKO strony Analiza gdzie karta jest full-width.

---

## Faza 4.3: CSV Import Flow

| # | Zadanie | Status |
|---|---|---|
| 4.3.1 | CSV parser (papaparse adapter + domain entities + preview) | 🔄 Rewrite (DEC-061) |
| 4.3.2 | DataGrid z edycją (AG Grid, editable cells, column mapping) | ⬜ |
| 4.3.3 | Smart batch edit (edit propagation, side panel UX) | ⬜ |
| 4.3.4 | Anonimizacja pipeline (auto regex + per-profile + manual review) | 🔄 Rewrite (DEC-061) |
| 4.3.5 | Import API integration (chunking, retry, progress, error handling) | ⬜ |

### Faza 4.3.E: Enterprise CSV Engine (DEC-061)

Full architecture: `docs/architecture/csv-anonymizer-engine.md`

| # | Zadanie | Status |
|---|---|---|
| 4.3.E.1 | Types rewrite + PiiDetector/DictionaryProvider/BankProfile interfaces | ⬜ |
| 4.3.E.2 | Dictionary provider (port) + dev JSON stubs (names, surnames, merchants, cities, phrases) | ⬜ |
| 4.3.E.3 | Parser: encoding-detector (jschardet) | ⬜ |
| 4.3.E.4 | Parser: separator-detector (statistical) | ⬜ |
| 4.3.E.5 | Parser: date-parser (multi-format, auto-detect) | ⬜ |
| 4.3.E.6 | Parser: amount-parser (multi-locale, auto-detect) | ⬜ |
| 4.3.E.7 | Parser: csv-parser orchestrator (encoding → sep → parse → validate) | ⬜ |
| 4.3.E.8 | Anonymizer: IBAN detector (regex + mod97 checksum) | ⬜ |
| 4.3.E.9 | Anonymizer: phone detector (PL + INT, context-aware) | ⬜ |
| 4.3.E.10 | Anonymizer: email detector | ⬜ |
| 4.3.E.11 | Anonymizer: name detector (dictionary + positional heuristics) | ⬜ |
| 4.3.E.12 | Anonymizer: address detector (street patterns) | ⬜ |
| 4.3.E.13 | Anonymizer: conflict-resolver (span overlap, priority, whitelist filter) | ⬜ |
| 4.3.E.14 | Anonymizer: masker (type-specific masking strategies) | ⬜ |
| 4.3.E.15 | Anonymizer: pipeline orchestrator (detect → filter → resolve → gate → mask) | ⬜ |
| 4.3.E.16 | Column mapper: bank profiles (mBank, PKO, ING, Santander, Revolut, generic) | ⬜ |
| 4.3.E.17 | Column mapper: auto-detector (sample-based column inference) | ⬜ |
| 4.3.E.18 | Integration tests: 50+ real-world transaction titles, accuracy metrics | ⬜ |
| 4.3.E.19 | Delete old naive implementations (anonymizer.ts, csv-parser.ts, column-mapper.ts) | ⬜ |

**Acceptance criteria:**
- Parser handles Windows-1250 + semicolons (most PL banks)
- Name detector ≥95% recall, <5% false positive
- IBAN detector 100% accuracy (mod97)
- Full pipeline: 1800 rows in <2 seconds
- Zero PII in errors/logs/stored state

### Zaimplementowane (Faza 4.0)

- **Struktura:** Feature-Sliced Design (app/pages/features/entities/shared) + layered internals per feature (domain/application/infrastructure/ui)
- **Entities:** Class-based, Uncle Bob (always valid or doesn't exist), transient (not in store)
- **Store:** ViewModels only (plain objects), Zustand behind port/facade interface, immer middleware OK
- **Server state:** TanStack Query (cache, refetch) — oddzielone od local state (Zustand)
- **Mappers:** Na każdej granicy (DTO↔Entity w infrastructure, Entity↔ViewModel w application)
- **Walidacja form:** Fowler pattern — Entity.create(values) → DomainError → field errors
- **Optimistic locking:** version field na ViewModel, 409 conflict handling
- **Fasady:** Zustand, TanStack Query, AG Grid, Nivo charts — wszystko za port/adapter interfaces

### Tooling Stack (DEC-034 → DEC-037)

- **Grid:** AG Grid Community (grupowanie, sort, paginacja, editable cells, row expand)
- **UI:** shadcn/ui + Radix + Tailwind CSS v4
- **Charts:** Nivo (za fasadą — możliwa wymiana na płatną lib)
- **Forms:** React Hook Form
- **Routing:** React Router v7
- **Dark mode:** Od razu (CSS vars, Tailwind dark:, class strategy)
- **Design system dev:** Storybook 10 (Vite-native, autodocs, dark mode toolbar)

---

## Milestone: MVP

MVP = Faza 1-3 (backend) + Faza 4.0-4.3 (frontend) ukończone. User może:
1. Wrzucić CSV z banku
2. Zanonimizować i przejrzeć dane w DataGrid
3. Przypisać kategorie (ręcznie + auto-reguły)
4. Zaimportować na serwer z dedup i PII validation
5. Przeglądać historię importów
6. Widzieć dashboard z KPI, wykresami, budżetami i ostatnimi transakcjami

---

## Odkładane na przyszłość (post-MVP)

- Analytics module (agregaty, wykresy)
- PostgreSQL + Drizzle (przejście z in-memory)
- AI categorization (Claude adapter)
- Optimistic locking + Unit of Work (przy PostgreSQL)
- Refresh token flow
- **Budget notifications** — user-configurable threshold per budget (e.g. 80%) + notification when approaching/exceeding limit with N days remaining in month (requires notification system infrastructure)

---

## Faza 5: Admin / Maintenance (post-MVP)

| # | Zadanie | Opis |
|---|---|---|
| 20 | Super-user role + guard | Dedykowany AuthGuard dla endpointów maintenance |
| 21 | Seed rules endpoint | `POST /admin/rules/seed` — bulk insert domyślnych reguł z JSON dictionary |
| 22 | Default rules dictionary (PL) | JSON seed 500-2000 reguł (merchants → kategorie), AI-enriched scraping |
| 23 | `isSystem` flag na CategorizationRule | Rozróżnienie systemowych (seed) vs user-created, UI hints |
| 24 | Seed categories hierarchy | Domyślne drzewo kategorii per locale (PL, EN), parentId support |
| 25 | Bulk rule import/export | `POST/GET /admin/rules/bulk` — JSON/CSV import/export dla super-usera |
| 26 | Workspace provisioning | Auto-seed rules + categories przy tworzeniu workspace |
| 27 | Rule analytics | Ile razy reguła matchowała, skuteczność, unused rules cleanup |
| 28 | System health endpoints | Stats: ile transakcji uncategorized, orphaned rules, etc. |

### Priority layering (convention)

```
priority 0     — systemowe (seed, AI-generated defaults)
priority 1-5   — user-defined rules
priority 10+   — explicit user overrides
```

User-created rules zawsze wygrywają nad systemowymi dzięki higher priority.
